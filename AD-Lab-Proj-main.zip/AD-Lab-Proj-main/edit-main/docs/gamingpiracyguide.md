***
***
**[◄◄ Back to Wiki Index](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/index)**
***
***

**Use [redirect bypassers](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/internet-tools#wiki_.25B7_redirect_bypass) to skip link shorteners**

***

# ► Download Games

* 🌐 **[/r/PiratedGames Mega](https://rentry.org/pgames)** / [Discord](https://discord.gg/dZWwhUy), **[CS.RIN Mega](https://cs.rin.ru/forum/viewtopic.php?f=10&t=95461)** or **[privateersclub](https://megathread.pages.dev/)** / [Discord](https://discord.gg/jz8dUnnD6Q) - Game Piracy Indexes
* 🌐 **[Wotaku](https://wotaku.wiki/games)** / [Discord](https://discord.gg/vShRGx8ZBC) or **[EverythingMoe](https://everythingmoe.com/?section=game)** / [Discord](https://discord.gg/GuueaDgKdS) - Otaku Games Indexes
* ↪️ **[Scene Release Trackers](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/storage#wiki_scene_release_trackers)**
* ⭐ **[CS.RIN.RU](https://cs.rin.ru/forum)** - Download / Forum / Account Required / [Status](https://csrinstaff.writeas.com/) / [Enhancement Mod](https://github.com/SubZeroPL/cs-rin-ru-enhanced-mod) / [Steam Buttons](https://github.com/Altansar69/CS.RIN.RU-Enhanced-external) / [.onion](http://csrinrutkb3tshptdctl5lyei4et35itl22qvk5ktdcat6aeavy6nhid.onion/forum)
* ⭐ **[GOG Games](https://gog-games.to/)** - Download / [.onion](http://goggamespyi7b6ybpnpnlwhb4md6owgbijfsuj6z5hesqt3yfyz42rad.onion/)
* ⭐ **[SteamRIP](https://steamrip.com/)** - Download / Torrent / Pre-Installs / [Discord](https://discord.gg/WkyjpA3Ua9) / PW: `1234` or `steamrip.com`
* ⭐ **[AnkerGames](https://ankergames.net/)** - Download / Pre-Installs / [Discord](https://discord.gg/nnMnGzDbwg)
* ⭐ **[Online Fix](https://online-fix.me/)** - Download / Torrent / Multiplayer / Signup Required / [Discord](https://discord.gg/yExgFYncMD) / [Telegram](https://t.me/onlinefix)
* ⭐ **[GamesDrive](https://gamesdrive.net/)** - Download / [Discord](https://discord.gg/wXdNEhf73x) / [Telegram](https://t.me/+qkrAOiq7k7ozNzRk)
* ⭐ **[Ova Games](https://www.ovagames.com/)** - Download / [Redirect Bypass Required](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/internet-tools#wiki_.25B7_redirect_bypass)
* ⭐ **[Torrminatorr](https://forum.torrminatorr.com/)** - Download / Forum / Account Required
* ⭐ **[SteamGG](https://steamgg.net/)** - Download / Pre-Installs / [Subreddit](https://www.reddit.com/r/OfficialSteamGG/) / [Discord](https://discord.gg/Rw6AT3hZZE)
* ⭐ **[FreeToGame](https://www.freetogame.com/games)**, [Acid Play](https://acid-play.com/) or [/v/'s Recommended](https://vsrecommendedgames.fandom.com/wiki/Freeware_Games) - F2P Games / [Trackers](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/misc#wiki_.25BA_free_stuff)
* ⭐ **[Game Download CSE](https://cse.google.com/cse?cx=006516753008110874046:cbjowp5sdqg)**, [Game Torrent CSE](https://cse.google.com/cse?cx=006516753008110874046:pobnsujblyx), [Rezi Search](https://rezi.one/), [Rave Search](https://idleendeavor.github.io/gamesearch/) / [2](https://ravegamesearch.pages.dev/) or [/r/PiratedGames CSE](https://cse.google.com/cse?cx=20c2a3e5f702049aa) - Multi-Site Search Engines
* [SteamUnderground](https://steamunderground.net/) - Download / Torrent / Pre-Installs / [Discord](https://discord.gg/ZjrNBhmhPz)
* [g4u](https://g4u.to/) - Download / PW: `404`
* [GameBounty](https://gamebounty.world/) - Download / [Discord](https://discord.gg/6msDMndrkD)
* [UnionCrax](https://union-crax.xyz/) - Download / [Discord](https://discord.gg/dkVame6BQS)
* [appnetica](https://appnetica.com/) - Download / Torrent / Pre-Installs
* [AtopGames](https://atopgames.com/) - Download / Pre-Installs / [Discord](https://discord.gg/KSG9Tg2s7b)
* [Reloaded Steam](https://reloadedsteam.com/) - Download / Pre-Installs / [Discord](https://discord.gg/XqMpBdVWvK)
* [Rexa Games](https://rexagames.com/) - Download / Pre-Installs / [Discord](https://discord.gg/6KWStFYSTj)
* [TriahGames](https://triahgames.com/) - Download / [Discord](https://discord.gg/vRxJNNcJNh) / PW: `www.triahgames.com`
* [GetFreeGames](https://getfreegames.net/) - Download / [Discord](https://discord.gg/Pc5TtEzk7k)
* [GLoad](https://gload.to/) - Download
* [World of PC Games](https://worldofpcgames.com/) - Download / Pre-Installs / Use Adblock / [Site Info](https://rentry.org/ikc3x8bt)
* [Games4U](https://games4u.org/) - Download / Use Adblock
* [AWTDG](https://awtdg.site/) - Download / [Discord](https://discord.gg/kApRXRjJ7A)
* [CG Games](https://www.cg-gamespc.com/) - Download
* [GamePCFull](https://gamepcfull.com/) - Download
* [Leeching Hell](http://www.leechinghell.pw/) - Download
* [IWannaPlay](https://sites.google.com/view/iwannaplay/список-игр) - Download / Telegram Required
* [IRC Games](https://redd.it/x804wg) - Download Games via IRC
* [ROM Heaven CSF](https://romheaven.com/csf), [2](https://romheaven.su/csf) - Download Clean Files

***

## ▷ Game Repacks

* **Note** - Repacks are compressed versions of games that exchange smaller downloads for longer installation times. Good if you have low bandwidth or data limits.

***

* ⭐ **[KaOsKrew](https://www.kaoskrew.org/)**, [Masquerade Repacks](https://discord.com/invite/HP5sQ6c) or [ScOOt3r Repacks](https://discord.gg/xe3Fys8Upy) - Download / Torrent / [Discord](https://discord.com/invite/WF2pqPTFBs)
* ⭐ **[FitGirl Repacks](https://fitgirl-repacks.site/)** - Download / Torrent / ROM Repacks / [Desktop Launcher](https://github.com/CarrotRub/Fit-Launcher/) / [Unofficial Discord](https://discord.gg/Up3YARe4RW)
* ⭐ **[DODI Repacks](https://rentry.co/FMHYBase64#dodi)** - Torrent / [Lootlink Bypass](https://rentry.co/lootlink) / **[Site Warning](https://github.com/fmhy/FMHY/wiki/FMHY%E2%80%90Notes.md#dodi-warning)** / [Discord](https://discord.gg/D9WU7C9FSE)
* ⭐ **[M4CKD0GE Repacks](https://m4ckd0ge-repacks.site/)** - Download / [Discord](https://discord.gg/693hNBdymb)
* ⭐ **[ARMGDDN Browser](https://github.com/KaladinDMP/AGBrowser)**, [2](https://cs.rin.ru/forum/viewtopic.php?f=14&t=140593) - Download / [Telegram](https://t.me/ARMGDDNGames)
* ⭐ **[Gnarly Repacks](https://rentry.co/FMHYBase64#gnarly_repacks)** - Download / PW: `gnarly`
* [Xatab Repacks](https://byxatab.com/) - Torrent
* [DigitalZone](https://digital-zone.xyz/) - Download / Portable Repacks / [Discord](https://discord.gg/ja3v2z26Sj)
* [Elamigos](https://elamigos.site/) - Download
* [Tiny-Repacks](https://www.tiny-repacks.win) - Torrent
* [FreeGOGPCGames](https://freegogpcgames.com/) - GOG Games Torrent Uploads / [Hash Note](https://github.com/fmhy/FMHY/wiki/FMHY%E2%80%90Notes.md#freegogpcgames-note), [2](https://i.ibb.co/XbF2dv1/image.png)
* [Magipack](https://www.magipack.games), [Old-Games](https://www.old-games.ru/), [CollectionChamber](https://collectionchamber.blogspot.com/) or [ClassicPCGames](https://archive.org/details/classicpcgames) - Retro PC Games
* [The U-M Software Archives](https://websites.umich.edu/~archive/) - Retro PC / Mac Games

***

## ▷ Virtual Reality

* ⭐ **[VRPirates](https://vrpirates.wiki/)** - VR Piracy Wiki / [Telegram](https://t.me/VRPirates) / [Discord](https://discord.com/invite/DcfEpwVa4a)
* ⭐ **[ARMGDDN Browser](https://cs.rin.ru/forum/viewtopic.php?f=14&t=140593)** - VR Games / [Telegram](https://t.me/ARMGDDNGames)
* [/r/QuestPiracy](https://www.reddit.com/r/QuestPiracy/) - Oculus Quest Piracy
* [SideQuest](https://sidequestvr.com/) - VR Sideloading Platform
* [VRCArena](https://www.vrcarena.com/) - Resources for Social VR Games
* [UEVR](https://uevr.io/) - Convert Unreal Engine Games to VR
* [Oculess](https://github.com/basti564/Oculess) - Remove Oculus Quest Account Requirements & Telemetry
* [ALVR](https://github.com/alvr-org/ALVR) - Stream VR Games from PC to Headset

***

## ▷ Abandonware

* ↪️ **[DOS](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/storage#wiki_dos_games)** / **[MSX Games](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/storage#wiki_msx_games)**
* ⭐ **[My Abandonware](https://www.myabandonware.com/)** - Abandonware
* ⭐ **[AbandonwareGames](https://abandonwaregames.net/)** - Abandonware
* [Flashtro](https://flashtro.com/) - Abandonware
* [Zombs-Lair](https://www.zombs-lair.com/) - Abandonware
* [OldGamesDownload](https://oldgamesdownload.com/) - Abandonware
* [Old-Games.com](https://www.old-games.com/) - Abandonware
* [VETUSWARE](https://vetusware.com/category/Games/) - Abandonware
* [Japanese PC Compendium](https://japanesepccompendium.blogspot.com/) - Retro Japanese PC Games
* [World of Spectrum](https://worldofspectrum.org/) or [SpectrumComputing](https://spectrumcomputing.co.uk/) - Sinclair ZX Spectrum
* [GamesNostalgia](https://gamesnostalgia.com/), [lemon64](https://www.lemon64.com/) or [C64.com](https://www.c64.com/) - Commodore 64
* [whdload](https://www.whdload.de/), [lemonamiga](https://www.lemonamiga.com/), [exotica](https://www.exotica.org.uk/) or [hol abime](https://amiga.abime.net/) - Amiga
* [LegendsWorld](https://www.legendsworld.net/) - Retro PC Adventures
* [Win7Games](https://win7games.com/) - Classic Windows Games

***

## ▷ Remakes / Ports

* 🌐 **[OSGL](https://trilarion.github.io/opensourcegames/)**, [Awesome Open Source Games](https://github.com/michelpereira/awesome-open-source-games) or [LibreGameWiki](https://libregamewiki.org/List_of_games) - Open-Source Games
* 🌐 **[Galaxy of Games](https://galaxyofgames.neocities.org/)** - PC Ports, Decompilations, Remakes, Fan Games and more
* 🌐 **[Awesome Game Remakes](https://github.com/radek-sprta/awesome-game-remakes)** or [Game Clones](https://osgameclones.com/) - Open-Source Remakes
* 🌐 **[Awesome Terminal Games](https://ligurio.github.io/awesome-ttygames/)** - ASCII Terminal Games
* 🌐 **[Kliktopia](https://kliktopia.org/)** - Klik Games
* ⭐ **[OpenRCT2](https://openrct2.io/)**, [2](https://openrct2.io/) - Open-Source RollerCoaster Tycoon 2
* [Luanti](https://www.luanti.org/) / [GitHub](https://github.com/luanti-org) or [Classicube](https://www.classicube.net/) - Open-Source Minecraft Alternatives
* [Locomalito](https://locomalito.com/) or [RetroSpec](https://retrospec.sgn.net/) - Classic Game Remakes
* [OpenFortress](https://openfortress.fun/) - Team Fortress 2 Mod
* [TF2 Classic](https://tf2classic.com/) - Team Fortress 2 Classic Mod
* [RisingHub](https://risinghub.net/) - Battlefield Heroes Revival Project
* [Chrono Divide](https://rentry.co/FMHYBase64#chrono-divide) or [OpenRA](https://openra.net/) - Command & Conquer Recreations / Ports
* [Beyond All Reason](https://www.beyondallreason.info/) - Open-Source Total Annihilation / Supreme Commander / [Discord](https://discord.gg/beyond-all-reason) / [GitHub](https://github.com/beyond-all-reason)
* [DFWorkshop](https://www.dfworkshop.net/) - Daggerfall Unity Engine Port
* [OpenMW](https://openmw.org/) - Morrowind Remake / [GitHub](https://github.com/OpenMW/openmw) / [Multiplayer](https://github.com/TES3MP/TES3MP)
* [ECWolf](https://maniacsvault.net/ecwolf/) - Wolfenstein 3D, Spear of Destiny & Super 3D Noah's Ark Port
* [IOQuake3](https://ioquake3.org/) - Quake 3 Source Port / [GitHub](https://github.com/ioquake/ioq3)
* [YQuake2](https://www.yamagi.org/quake2/) - Quake 2 Source Port / [GitHub](https://github.com/yquake2/yquake2)
* [Xonotic](https://xonotic.org/) - Open-Source Modified Quake Engine FPS
* [Silent Hill 2: Enhanced Edition](https://enhanced.townofsilenthill.com/SH2/) - Silent Hill 2 Mod Project
* [Unleashed Recompiled](https://rentry.co/FMHYBase64#unleashed-recompiled) - Sonic Unleashed PC Port
* [Sonic 3 A.I.R.](https://sonic3air.org/) - Sonic 3 & Knuckles Enhanced / [Mods](https://gamebanana.com/games/6878), [2](https://sonic3air.boards.net/board/6/mod-releases) / [Discord](https://dc.railgun.works/s3air) / [GitHub](https://github.com/Eukaryot/sonic3air)
* [TeamForever](https://teamforeveronline.wixsite.com/home) - Sonic 1 & 2 Enhanced / [S1F Mods](https://gamebanana.com/games/10601) / [S2A Mods](https://gamebanana.com/games/15019) / [YouTube](https://www.youtube.com/@teamforeverdev) / [Tumblr](https://www.tumblr.com/teamforever)
* [SRB2](https://www.srb2.org/) - Open-Source Sonic Fan Game / [GitLab](https://git.do.srb2.org/STJr/SRB2)
* [SRB2Kart](https://mb.srb2.org/threads/srb2kart.25868/) / [GitHub](https://github.com/STJr/Kart-Public) or [RingRacers](https://github.com/KartKrewDev/RingRacers) - Open-Source Sonic Kart Games
* [Aleph One](https://alephone.lhowon.org/) - Open-Source Marathon Continuation
* [REDRIVER2](https://github.com/OpenDriver2/REDRIVER2) - Driver 2 PC Port
* [Streets of Rage Remake](https://sorr.forumotion.net/t838-new-streets-of-rage-remake-v5-2-download-and-info) - Streets of Rage Remake
* [OpenSA](https://github.com/Dzierzan/OpenSA) - Swarm Assault Recreation / [OpenRA Required](https://www.moddb.com/mods/opensa) / [Non OpenRA Version](https://dzierzan.itch.io/opensa)
* [EDuke32](https://www.eduke32.com/) - Duke Nukem 3D Source Port
* [NBlood](https://github.com/NBlood/NBlood) - Reverse-Engineered Duke Nukem Ports
* [SP Tarkov](https://www.sp-tarkov.com/) - Escape From Tarkov Single Player Mod
* [doukutsu-rs](https://github.com/doukutsu-rs/doukutsu-rs) - Open-Source Cave Story
* [Arx Libertatis](https://arx-libertatis.org/) - Arx Fatalis PC Port
* [Mars 3D](https://mars3d-game.wixsite.com/index) - Mars 3D Translation & Remake
* [Unciv](https://github.com/yairm210/Unciv) - Civilization V Remake
* [FreeCiv](https://www.freeciv.org/) - Civilization Remake / [GitHub](https://github.com/freeciv)
* [OpenTTD](https://www.openttd.org/) - Transport Tycoon Remake
* [CannonBall](https://github.com/djyt/cannonball) - OutRun Remake / [Video](https://youtu.be/t-93kDC8Vac)
* [EDOPro](https://projectignis.github.io/) - Yu-Gi-Oh! TCG Fangame
* [OpenNox](https://github.com/noxworld-dev/opennox) - Nox Revival Project
* [Pixel Gun X](https://discord.com/invite/8796Fs9tZm) - Pixel Gun 3D Revival Project Discord
* [Infinity Blade PC](https://rentry.co/FMHYBase64#ib-pc-port) - Infinity Blade PC Port / [Subreddit](https://www.reddit.com/r/infinityblade) / [Discord](https://discord.gg/GfX3pmC)
* [Pac-Man](https://github.com/masonicGIT/pacman) - Pac-Man with Added Features
* [SpaceCadetPinball](https://github.com/k4zmu2a/SpaceCadetPinball) - Space Cadet Pinball / [Android](https://github.com/fexed/Pinball-on-Android)
* [Visual Pinball](https://github.com/vpinball/vpinball) - Pinball Table Editor / Simulator / [Tables](https://www.vpforums.org/)
* [YARC-Official](https://github.com/YARC-Official) - Rock Band Clone / [Launcher](https://github.com/YARC-Official/YARC-Launcher/releases) / [Discord](https://discord.gg/sqpu4R552r)
* [Clone Hero](https://clonehero.net/) - Guitar Hero Clone / [Setlists](https://rentry.co/FMHYBase64#setlists), [2](https://customsongscentral.com/), [3](https://rentry.co/FMHYBase64#frif-drive) / [Wii Controller Support](https://github.com/Meowmaritus/WiitarThing) / [Custom Client](https://clonehero.scorespy.online)
* [Bridge](https://github.com/Geomitron/Bridge) - Download Charts for Rhythm Games
* [ITGmania](https://www.itgmania.com/) - DDR Clone
* [beatoraja](https://mocha-repository.info/) - BMS Player as Alternative to IIDX / [beatoraja English Guide](https://github.com/wcko87/beatoraja-english-guide/wiki)
* [Unnamed SDVX clone](https://github.com/Drewol/unnamed-sdvx-clone) - Sound Voltex Clone
* [OpenTaiko](https://github.com/0auBSQ/OpenTaiko) - Taiko no Tatsujin Clone / [Taiko Simulator Guide](https://guide.tjadataba.se/)
* [Etterna](https://etternaonline.com/) or [Quaver](https://quavergame.com/) - O2Jam Clones
* [osu!](https://osu.ppy.sh/home), [osu!droid](https://osudroid.moe/) or [McOsu](https://store.steampowered.com/app/607260/McOsu/) - Osu! Tatakae! Ouendan Clones
* [PPD](https://projectdxxx.me/) - Project Diva Clone
* [Rhythia (Discord)](https://discord.gg/rhythia) - Sound Space Clone
* [Cytoid](https://cytoid.io/) - Cytus Clone
* [Sonolus](https://sonolus.com/) - Project Sekai Clone / [GitHub](https://github.com/Sonolus) / [Guides](https://wiki-en.purplepalette.net/home)

***

## ▷ Special Interest

* ⭐ **[itch.io](https://itch.io/games/new-and-popular/featured/free)**, [Killed By A Pixel](https://frankforce.com/all-games/), [Gamdie](https://gamdie.com/), [Indie Rentry](https://rentry.org/hhtxv7ud), [DigiPen](https://games.digipen.edu/) or [Game Jolt](https://gamejolt.com/games?price=free) - Indie Games
* ⭐ **itch.io Tools** - [Downloader](https://github.com/Emersont1/itchio) / [Desktop](https://github.com/itchio/itch) / [Mobile](https://sr.ht/~gardenapple/mitch/) / [Auto-Claim](https://github.com/Smart123s/ItchClaim)
* [Alpha Beta Gamer](https://alphabetagamer.com/) - Play Games in Alpha / Beta Testing
* [Necromanthus](https://necromanthus.com/) - 3D Shockwave Games
* [LemmaSoft](https://lemmasoft.renai.us/) - Visual Novel Games / [Discord](https://discord.gg/6ckxWYm)
* [vgperson](https://vgperson.com/games/) - Simple Japanese Games
* [Ninja Kiwi Archive](https://ninjakiwi.com/archive) - Ninja Kiwi / Bloons Archive
* [SAGE](https://sagexpo.org/) - Sonic Fan Games / [Discord](https://discord.sonicfangameshq.com/)
* [DoujinStyle](https://doujinstyle.com) - Doujin Games / [Discord](https://discord.com/invite/z2QDFdA)
* [MoriyaShrine](https://moriyashrine.org/) - Touhou Games
* [Planet Casio](https://www.planet-casio.com/Fr/programmes/jeux-casio.php) or [Cemetech](https://cemetech.net/) - Calculator Games
* [UnorthodoxFun](https://github.com/rarelygoeshere/UnorthodoxFun) - Games on Unorthodox Platforms
* [GamesOnPDF](https://github.com/rarelygoeshere/GamesOnPDF) - PDF Games
* [GrimReaper's Scene ISO Collection](https://archive.org/details/@waffess) - ISO Collection
* [Redump Forum](http://forum.redump.org/) - Disc Preservation Project
* [/r/CrackSupport](https://reddit.com/r/CrackSupport) - Cracking Discussion / [Matrix](https://matrix.to/#/!MFNtxvVWElrFNHWWRm:nitro.chat?via=nitro.chat&via=envs.net&via=matrix.org) / [Guilded](https://guilded.gg/crackwatch) / [FAQ](https://rentry.co/cracksupport)

***

## ▷ [Linux Games](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/linux#wiki_.25B7_linux_gaming)

***

## ▷ [Mac Games](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/linux#wiki_.25B7_mac_gaming)

***

# ► Emulation / ROMs

## ▷ Emulators

* 🌐 **[Emulation Wiki](https://emulation.gametechwiki.com/)**, [Awesome Emulators](https://github.com/DerekTurtleRoe/awesome-emulators), [PlanetEmu](https://www.planetemu.net/), [The Emulator Zone](https://www.emulator-zone.com/) or [EmuCR](https://www.emucr.com/) - Download Emulators
* 🌐 **[Multi System Emulators](https://emulation.gametechwiki.com/index.php/Multi-system_emulators)** / [Frontends](https://emulation.gametechwiki.com/index.php/Frontends) - Emulators with Multiple Consoles
* 🌐 **[RedSquirrel Project List](https://www.redsquirrel87.altervista.org/doku.php/projects-list)** - Emulator Tools
* 🌐 **[Multiplayer Emulation](https://emulation.gametechwiki.com/index.php/Netplay)** - Multiplayer Emulation Tools
* ↪️ **[Android Emulators](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/android#wiki_.25BA_android_emulators)**
* ⭐ **[Recommended Emulator Specs](https://emulation.gametechwiki.com/index.php/Computer_specs)**
* ⭐ **[Emulator BIOS Files](https://rentry.co/FMHYBase64#emulator-files)** / **[Firmware Files](https://rentry.co/FMHYBase64#console-firmware)** / [2](https://rentry.co/FMHYBase64#sigmapatches)
* ⭐ **[RetroAchievements](https://retroachievements.org/)** - Achievements for Emulators
* ⭐ **[Dolphin Guide](https://github.com/shiiion/dolphin/wiki/Performance-Guide)** - Dolphin Setup Guide
* ⭐ **[Cemu Guide](https://cemu.cfw.guide/)** or [/r/CemuPiracy Tutorial](https://www.reddit.com/r/CemuPiracy/wiki/tutorial/) - Wii U / BOTW Setup Guides
* ⭐ **[Switch Emu Guide](https://github.com/Abd-007/Switch-Emulators-Guide)**, [Switch Emulation](https://rentry.co/FMHYBase64#switch-emulation) or [Ryujinx Guide](https://docs.google.com/document/d/1prxOJaE4WhPeYNHW17W5UaWZxDgB8e5wNHxt2O4FKvs/) - Switch Emulator Setup Guides
* ⭐ **[RAZE](https://github.com/ZDoom/Raze)** or [BuildGDX](https://m210.duke4.net/) / [Discord](https://discord.gg/zZw2eq3n7G) - Oldschool Shooter Engine
* [RetroCatalog](https://retrocatalog.com/) or [Handheld Emulation Compatibility](https://docs.google.com/spreadsheets/d/1irg60f9qsZOkhp0cwOU7Cy4rJQeyusEUzTNQzhoTYTU/) - Handheld Emulation Compatibility / Info
* [TOSEC](https://rentry.co/FMHYBase64#tosec) - The Old School Emulation Center
* [Emulation Collective](https://discord.com/invite/7pcAbZzpXj) - Xbox One/Series X|S UWP Emulation Discord
* [MouseInjector](https://github.com/garungorp/MouseInjectorDolphinDuck) - Add Mouse Support to Emulators
* [SaveFileConverter](https://savefileconverter.com/) - Convert Console Saves to Emulator Saves
* [Motion Support Bypass](https://redd.it/gobcne) - Fix Cemu BOTW Motion Shrines / [DL](https://mega.nz/file/1Uo3BI6L#X5m-bPK27-X-IijzJH1o4MloivkUqP33zsUJE_kpOdc)
* [SwitchEmuModDownloader](https://github.com/amakvana/SwitchEmuModDownloader) - Download Switch Emulator Mods
* [Green Leaf](https://discord.gg/m6z3ra8ssh) - Switch Saves Discord
* [TOTK Optimization](https://rentry.co/FMHYBase64#totk-optimization) - TOTK Optimization / Fixes
* [UniversalDynamicInput](https://github.com/Venomalia/UniversalDynamicInput) - Custom Dolphin Button Pack
* [Prime Hack](https://github.com/Kekun/primehack) or [Prime Hunter Hack](https://github.com/IBreakGames/PrimeHunterHack) - Add Mouse Support to Metroid Games
* [RPCS3 Setup Guide](https://docs.google.com/document/d/1gdjNab-CtVS97jH2diPPP5tCrpBeof9-qPIRRB9-BrU/edit) - RPCS3 Emulator Setup Guide
* [PCSX-Redux](https://pcsx-redux.consoledev.net) - PSCX Development Emulator
* [Modernized PCSX2 Settings](https://mega.nz/folder/WdNAlY5Z#K6PmrQFyDm2k7BEV8KoAmg) - Premade PCSX2 Settings
* [PictoChat Online](https://pict.chat/) - Browser DS PictoChat
* [Mudlet](https://www.mudlet.org/) - Text Adventure Game Platform
* [webnofrendo](https://zardam.github.io/webnofrendo/) - NES Numworks Emulator

***

## ▷ ROM Sites

* 🌐 **[ROM Sites Wiki](https://emulation.gametechwiki.com/index.php/ROM_%26_ISO_Sites)** - List of ROM Download Sites
* 🌐 **[ROM Managers](https://emulation.gametechwiki.com/index.php/ROM_managers)** - List of ROM Managers
* ↪️ **[Switch ROMs](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/storage#wiki_switch_roms)**
* ⭐ **[/r/ROMs Mega](https://r-roms.github.io/)** - ROMs / [Pastebins](https://rentry.co/FMHYBase64#romcenter)
* ⭐ **[Myrient](https://rentry.co/FMHYBase64#myrient)** - ROMs
* ⭐ **[AlvRo](https://rentry.co/FMHYBase64#alvro)** - ROMs / PW: `ByAlvRo`
* ⭐ **[No-Intro](https://rentry.co/FMHYBase64#no-intro)** - ROMs
* ⭐ **[ROM Heaven](https://romheaven.com/)**, [2](https://romheaven.su) - ROMs
* ⭐ **[CrocDB](https://crocdb.net/)** - Emulators / ROMs
* ⭐ **[RetroGameTalk](https://retrogametalk.com/)** - ROMs / [Discord](https://cdromance.org/discord)
* ⭐ **[WiiUDownloader](https://github.com/Xpl0itU/WiiUDownloader)**, [WiiUSBHelper](https://github.com/FailedShack/USBHelperInstaller/releases) or [JNUSTool](https://gbatemp.net/threads/jnustool-nusgrabber-and-cdecrypt-combined.413179/) - ROMs / Wii U
* ⭐ **[Skraper](https://www.skraper.net/)** - ROM Cover / Metadata Scraper
* [ROMhacking](https://www.romhacking.net/) or [Reality Incorporated](https://sites.google.com/view/bonmarioinc/rom-hacks/released-rom-hacks) - ROM Fan Translations
* [/r/ROMs](https://www.reddit.com/r/ROMs/) - Discussion Sub
* [Vimms Lair](https://vimm.net/) - Emulators / ROMs
* [AliceISO](https://alice.al/) - ROMs
* [Gnarly Repacks](https://rentry.co/FMHYBase64#gnarly_repacks) - ROMs / Emulator Repacks
* [ROM-Collections](https://rentry.co/FMHYBase64#rom-collections) - ROMs
* [WowROMs](https://wowroms.com/en) - ROMs
* [Retro Game Champion](https://www.retrogamechampion.com/) - Retro Game ROMs, Magazines, Music & more
* [Edge Emulation](https://edgeemu.net/) - ROMs
* [Zophar's Domain](https://www.zophar.net/) - Emulators / ROM Mods
* [TheRomDepot](https://theromdepot.com/) - ROMs
* [BlueRoms](https://www.blueroms.ws/) - Emulators / ROMs / Torrents
* [Arquivista ROMs](https://rentry.co/FMHYBase64#arquivista) - ROMs
* [FinalBurn Neo](https://rentry.co/FMHYBase64#finalburn-neo) - ROMs / Zip
* [Romsie](https://roms2000.com/) - Emulators / ROMs
* [Retrostic](https://www.retrostic.com/) - Emulators / ROMs
* [Romsever](https://romsever.com) - Emulators / ROMs
* [ROMsGames](https://www.romsgames.net/roms/) - Emulators / ROMs
* [ConsoleROMs](https://www.consoleROMs.com/) - Emulators / ROMs
* [Emu-Land](https://www.emu-land.net/en) - Emulators / ROMs
* [HexRom](https://hexrom.com/) - Emulators / ROMs
* [GameGinie](https://gameginie.com/) - Emulators / ROMs
* [The Old Computer](https://www.theoldcomputer.com/) - Emulators / ROMs
* [Emulator Games](https://www.emulatorgames.net/) - Emulators / ROMs
* [Emuparadise](https://www.emuparadise.me/) - Emulators / ROMs / [Forum](https://www.epforums.org/) / [Workaround Script](https://web.archive.org/web/20230115181306/https://gist.github.com/byzantium225/484101c7846ce18e514b7b10bf4815c2)
* [ROMsPURE](https://ROMspure.cc/) - Emulators / ROMs
* [Romspedia](https://www.romspedia.com/) - Emulators / ROMs
* [TechToROMs](https://techtoroms.com/) - Emulators / ROMs
* [RPGOnly](https://rpgonly.com) - ROMs
* [GLoad](https://gload.to/) - ROMs
* [AllMyROMs](https://www.allmyroms.net/) - ROMs
* [ROMsFun](https://romsfun.com/) - ROMs
* [FreeROMs](https://www.freeroms.com/) - ROMs
* [RetroZone](https://retrozone.co/) - ROMs
* [NGR](https://www.nextgenroms.com/) - ROMs
* [FantasyAnime](https://fantasyanime.com/) - ROMs
* [Ziperto](https://ziperto.com/) - ROMs / Avoid [Fake](https://ibb.co/wWJbkX6) Buttons
* [Rom Magnet Links](https://emulation.gametechwiki.com/index.php/ROM_%26_ISO_Sites#BitTorrent) - ROMs / Torrent
* [ROM CSE](https://cse.google.com/cse?cx=f47f68e49301a07ac) / [CSE 2](https://cse.google.com/cse?cx=744926a50bd7eb010) - Multi-Site ROM Search
* [Wad Archive](https://archive.org/details/wadarchive) - 83k WAD Files
* [Cah4e3](https://cah4e3.shedevr.org.ru/) - Unlicensed ROMs / Bootlegs
* [Muds](https://muds.fandom.com/wiki/) - Text Adventure ROM Wiki
* [MarioCube](https://mariocube.com/) - ROMs / Wii / Gamecube
* [64DD.org](https://64dd.org/) - ROMs / 64DD
* [3DS ROMS](https://3dsroms.org), [taodung](https://taodung.com/) or [hShop](https://hshop.erista.me/) - ROMs / 3DS
* [NoPayStation](https://nopaystation.com/) - ROMs / Playstation Consoles
* [SuperPSX](https://www.superpsx.com/) - ROMs / PS3 / PS4
* [PKGPS4](https://www.pkgps4.click/) or [Game-2u PS4](https://game-2u.com/Category/game/ps4) / [Note](https://github.com/fmhy/FMHY/wiki/FMHY%E2%80%90Notes.md#game-2u-ps4-note) - ROMs / PS4
* [/r/PkgLinks1](https://www.reddit.com/r/PkgLinks1/) - PS1 / PS2 Games for Modded PS4
* [PSVitaVPK](https://psvitavpk.com/) - ROMs / PSP
* [xbarchive](https://github.com/codemasterv/xbarchive) - ROMs / Xbox Consoles
* [AtariMania](https://www.atarimania.com/) - ROMs / Emulators / Atari Consoles
* [Homebrew Hub](https://hh.gbdev.io/) - Homebrew ROMs / NES / Gameboy
* [NesFiles](https://www.nesfiles.com/) or [FC Gallery](https://fcpic.nesbbs.com/index_en.html) - ROMs / NES / Famicom
* [/1CC/](https://1cc.kr.eu.org/1cc/index.html) / [Discord](https://discord.com/invite/e7xffWFf9p), [ROMs For MAME](https://www.romsformame.com/), [MDK](https://mdk.cab/), [PleasureDome](https://pleasuredome.github.io/pleasuredome/mame/), [MAME World](https://mameworld.info/) or [Arcade Database](http://adb.arcadeitalia.net/default.php?lang=en) - Arcade MAME ROMs
* [Kuribo64](https://kuribo64.net/) - ROM Modding Community
* [MFGG](https://mfgg.net/) - Super Mario Mods / [Discord](https://discord.gg/jchgfw5)
* [Newer Team](https://newerteam.com/) or [NSMBHD](https://nsmbhd.net/) - Super Mario Bros. DS / Wii Mods
* [SMWCentral](https://smwcentral.net/) - Super Mario World ROM Mods
* [Wario Land Vault](https://wario-land.github.io/HackVault/index.html) - Wario Land ROM Mods
* [Pokemerald](https://pokemerald.com/) or [PokemonXenoverse](https://pokemonxenoverse.com/) - Pokémon ROM Mods
* [MetroidConstruction](https://metroidconstruction.com/) - Metroid ROM Modding Community / [Discord](https://discord.gg/xDwaaqa)
* [PICOwesome](https://rentry.co/FMHYBase64#picowesome) - PICO-8 ROMs
* [POP Unofficial Website](https://popuw.com/) - Prince of Persia ROMs / Mods
* [Ship of Harkinian](https://www.shipofharkinian.com/) - Ocarina of Time PC Port / [Discord](https://discord.com/invite/shipofharkinian) / [GitHub](https://github.com/HarbourMasters/Shipwright)
* [OOTMM](https://ootmm.com/) - Randomize + Merge Ocarina of Time with Majora's Mask
* [Super Mario Bros Crossover](https://archive.org/details/SuperMarioCrossoverOffline) - Play SMB with Alternative Characters
* [perfect_dark](https://github.com/fgsfdsfgs/perfect_dark), [2](https://github.com/n64decomp/perfect_dark) - Perfect Dark Decompilation
* [Mega Man Maker](https://megamanmaker.com/) - Create Mega Man Levels
* [Dan's Palace](https://discord.gg/RqQeZwrP8k) - Android / PSVita PC Game Ports Discord / [Telegram](https://t.me/danspalace)
* [wide-snes](https://github.com/VitorVilela7/wide-snes) - Widescreen Super Mario World
* [Dats.site](https://dats.site/) or [No Intro](https://no-intro.org/) - ROM .dat Files
* [Dat-O-Matic](https://datomatic.no-intro.org/index.php) - ROM Datasets
* [NSWDB](https://www.nswdb.com) - Switch Release Tracker
* [RomStation](https://www.romstation.fr/) - ROM Downloader / Manager / Multiplayer
* [RomPatcher](https://www.marcrobledo.com/RomPatcher.js/), [Rom Patcher JS](https://www.romhacking.net/patch/), [Hack64 Patcher](https://hack64.net/tools/patcher.php) or [FFF6Hacking Patcher](https://www.ff6hacking.com/patcher/) - Online ROM Patchers

***

## ▷ Browser Emulators

* 🌐 **[Browser Emulator Index](https://emulation.gametechwiki.com/index.php/Emulators_on_browsers)** - List of Browser Emulators
* ↪️ **[Multi-Console Browser Emulators](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/storage#wiki_multi-console_browser_emulators)**
* ⭐ **[Telemelt](https://telemelt.com/)** - Multiplayer Browser Emulator
* ⭐ **[PSX Party](https://psxparty.kosmi.io/)** - Multiplayer Playstation Browser Emulator
* [PS1FUN](https://www.ps1fun.com/) - PS1 Browser Emulator
* [LetsPlayGB](https://www.letsplaygb.com/) - Game Boy Browser Emulator
* [SNESFun](https://www.snesfun.com/) - SNES Browser Emulator
* [8bbit](https://www.8bbit.com/) or [Play NES](https://www.playnesonline.com/) - NES Browser Emulators
* [Homebrew Hub](https://hh.gbdev.io/) - Homebrew ROM Emulator / NES / Gameboy
* [SSega](https://www.ssega.com/) or [Sega Play](https://sega-play.online/) - Sega Browser Emulators
* [Let's Play Sega](https://www.letsplaysega.com/) - Sega Genesis Browser Emulator
* [Mega Drive Emulator](https://megadrive-emulator.com/) - Sega Megadrive Browser Emulator
* [Capcom Town](https://captown.capcom.com/en/retro_games) - Capcom Browser Emulator
* [DosGames](https://dosgames.com/), [DOSDeck](https://dosdeck.com/), [PlayOldGames](https://playold.games/), [DOSZone](https://dos.zone/), [MSDOSGames](https://msdosgames.com/) or [PlayDOSGames](https://www.playdosgames.com/) - DOS Browser Emulators
* [NeoGeoFun](https://www.neogeofun.com/) - Neo Geo Browser Emulator
* [RetroFab](https://itizso.itch.io/retrofab) or [LCD Games](http://bdrgames.nl/lcdgames/) - Retro LCD Game Emulators
* [File-Hunter](https://www.file-hunter.com/) - MSX / Amiga Browser Emulator
* [QAOP](https://torinak.com/qaop/games) - ZX Spectrum
* [MSXGamesWorld](https://www.msxgamesworld.com/) or [CheatMSX](https://www.cheatmsx.com/) - MSX Browser Emulators
* [CommodoreGames](https://www.commodoregames.net/) or [C64Online](https://c64online.com/) - C64 Browser Emulators
* [SMBGames](https://smbgames.be/) - Super Mario Browser Emulator
* [SMWGames](https://www.smwgames.com/) - Modded Super Mario World Browser Emulators
* [Jelly Mario](https://jellymar.io/) - Jelly Super Mario
* [SMBX2](http://codehaus.wohlsoft.ru/index.php) - Super Mario Enhancement Mod / [Levels](https://rentry.co/FMHYBase64#smbx-preservation) / [Video](https://youtu.be/15ia-OiEFzQ) / [Discord](https://discord.com/invite/aCZqadJ)
* [Super Mario and the Rainbow Stars](https://superstarshi.github.io/smatrs/) - Super Mario Mod / [Video](https://youtu.be/SqQuI1AbSQw) / [Discord](https://discord.gg/GBXUa7NF2J)
* [Level Share Square](https://levelsharesquare.com/) - Custom Maps for Mario Fangames
* [Mario Kart PC](https://mkpc.malahieude.net/mariokart.php) - Browser Mario Kart
* [Mega Man Games](https://www.megamangames.net/) - Mega Man Browser Emulator
* [Q1K3](https://js13kgames.com/games/q1k3/index.html) - Quake Inspired Browser Game
* [Lain Game](https://laingame.net/) - Lain Game Browser Emulator
* [OpenLara](http://xproger.info/projects/OpenLara/) - Classic Tomb Raider in Browser / [GitHub](https://github.com/XProger/OpenLara)
* [You Have Not Died Of Dysentery](https://woe-industries.itch.io/you-have-not-died-of-dysentery) - Oregon Trail with Alt Dysentery Mechanics
* [The World's Biggest Pac-Man](https://worldsbiggestpacman.com/) - Giant Pac-Man
* [Tetris](https://tetris.com/), [Tetr.js](http://farter.cn/tetr.js/), [OpenTetris Classic](https://sourceforge.net/projects/opentetrisclassic/) or [NullpoMino](https://github.com/nullpomino/nullpomino) - Play Tetris
* [TETR.IO](https://tetr.io/) - Multiplayer Tetris / [Plus](https://gitlab.com/UniQMG/tetrio-plus) / [Skin Database](https://you.have.fail/tetrioplus//) / [Stats](https://tetrio.team2xh.net/)
* [Jstris](https://jstris.jezevec10.com/) - Multiplayer Tetris / [Plus](https://discord.gg/mtX8ek82xb) / [Skin Database](https://docs.google.com/spreadsheets/d/1xO8DTORacMmSJAQicpJscob7WUkOVuaNH0wzkR_X194/htmlview#)
* [First-Person Tetris](https://firstpersontetris.com/) - Play Tetris in First Person
* [Sandtris](https://sandtris.com/) - Falling Sand Style Tetris
* [Play Snake](https://playsnake.org/) - Retro Snake
* [Google Snake Mods](https://googlesnakemods.com/) - Google Snake Mods
* [Snake-Game](https://www.onemotion.com/snake-game/) - 3D Snake
* [TENNIS!](https://snek-vunderkind.vercel.app/games/tennis.html) - JavaScript Pong

***

# ► Browser Games

* ↪️ **[Interactive Text Adventures](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/storage#wiki_text_adventures)**
* ⭐ **[Flashpoint](https://flashpointarchive.org/)** / [Discord](https://discord.gg/Z4gGtJvvn8), [Flash by Night](http://www.flashbynight.com/) or [Flash Library](https://rentry.co/FMHYBase64#software-library-flash) - Flash Game Archives
* ⭐ **[Marble Blast Gold Web](https://marbleblast.vaniverse.io/)** or [Marble Blast Ultra](https://marbleblastultra.randomityguy.me/) - Marble Blast in Browser
* ⭐ **[Allchemy](https://allchemy.io/)** or [Infinite Craft](https://neal.fun/infinite-craft/) / [Wiki](https://expitau.com/InfiniteCraftWiki/) / [Search](https://infinibrowser.wiki/) - Infinite Item Crafting Games
* ⭐ **[QWOP](https://www.foddy.net/Athletics.html)** - Ragdoll Running Game
* [Minecraft Classic](https://classic.minecraft.net/) - Browser Minecraft
* [Slither.io](http://slither.io/) - Grow the Longest Worm
* [Hexar.io](http://www.hexar.io/) or [splix.io](https://splix.io/) - Control the Map
* [agar.io](https://agar.io/) - Become the Biggest Circle
* [SpaceCadetPinball](https://alula.github.io/SpaceCadetPinball) - Browser Space Cadet Pinball
* [The Circle](https://the-circle.app/) - Dodge Circles
* [JoeDangerTheGame](https://joedangerthegame.com/) - Trials Inspired Game
* [Polka Dot Game](https://www.polkadotgame.com/) - Dodge & Eat Dots
* [Launch Ball](https://launchball.sciencemuseum.org.uk/) - Physics Game w/ Map Creator
* [Spinner](https://hyperspace-wizard.itch.io/spinner) - Spinner Timing Game
* [Ehmorris](https://ehmorris.com/lander/) - Spaceship Landing Game
* [Dino Swords](https://dinoswords.gg/) - Stay Alive by Jumping / Destroying Cacti
* [Rhythm Plus](https://rhythm-plus.com), [2](https://rhythmplus.io/) - Rhythm Game / [Discord](https://discord.com/invite/ZGhnKp4) / [GitHub](https://github.com/henryzt/Rhythm-Plus-Music-Game)
* [Bemuse](https://bemuse.ninja/) - Rhythm Game
* [Pulsus](https://www.pulsus.cc/play/) - 3x3 Tile Board Rhythm Game
* [Sans Fight](https://jcw87.github.io/c2-sans-fight/) - Undertale Fight Simulator
* [DB Evolution](https://www.txori.com/dbdevolution) - Dragon Ball Fighting Game
* [Flappy Bird](https://flappybird.io/) - HTML5 Flappy Bird
* [Slope Plus](https://coweggs.itch.io/slope-plus) - Downhill Ball Game
* [Rooms](https://rooms.xyz/) - Room Design Game / [Discord](https://discord.gg/rooms)
* [Haxball](https://www.haxball.com/) - Physics-Based Soccer
* [Mexican Train](https://mexicantrain.online/) - Domino Train Game
* [racing-game](https://racing.pmnd.rs/) - Driving Game / [GitHub](https://github.com/pmndrs/racing-game) / [Discord](https://discord.gg/dQW7fDmaAG)
* [The Race](https://therace.montblanclegend.com/), [2](https://therace.montblancexplorer.com/) - Driving Game
* [slow roads](https://slowroads.io/) - Driving Game
* [The Multiverse](https://across-multiverse.com/) - Universe Exploration Game Across
* [Starshine Legacy](https://starshine-legacy.starstable.com/index.html) - 3D Browser Mystery Game
* [Neopets](https://www.neopets.com/), [tamaNOTchi](https://tamanotchi.world/) or [Marapets](https://www.marapets.com) - Virtual Pet Game
* [Gaia Online](https://www.gaiaonline.com/) - Anime Virtual Pet
* [Edu-Games](https://www.edu-games.org/) - Educational Games

***

## ▷ Multi-Game Sites

* ⭐ **[itch.io web games](https://itch.io/games/free/platform-web)** - Browser Games
* ⭐ **[Newgrounds](https://www.newgrounds.com/games)** - Browser Games
* ⭐ **[Armor Games](https://armorgames.com/)** - Browser Games
* [Browser Craft](https://browsercraft.com/) - Indie Browser Games
* [RG Games](https://www.rgshows.me/games/) - Browser Games / [Discord](https://discord.gg/e34HMTgyEy)
* [Addicting Games](https://www.addictinggames.com/) - Browser Games
* [Kongregate](https://www.kongregate.com/) - Browser Games
* [Y8](https://www.y8.com/) - Browser Games
* [Poki](https://poki.com/) - Browser Games
* [Crazy Games](https://www.crazygames.com/) - Browser Games
* [GamezHero](https://www.gamezhero.com/) - Browser Games
* [Deepnight](https://deepnight.net/) - Browser Games
* [Nicky Case](https://ncase.me/) - Browser Games
* [yell0wsuit](https://yell0wsuit.page/games.html) - Browser Games
* [watabou](https://watabou.itch.io/) - Browser Games
* [DAN-BALL](https://dan-ball.jp/en/) - Browser Games
* [Miniplay](https://www.miniplay.com/) - Browser Games
* [Yandex Games](https://yandex.com/games/) - Browser Games
* [Arkadium](https://www.arkadium.com/) - Browser Games
* [classroom-6x](https://www.classroom-6-x.games/) - Browser Games
* [GamePix](https://www.gamepix.com/) - Browser Games
* [RoundGames](https://www.roundgames.com/) - Browser Games
* [Snokido](https://www.snokido.com/) - Browser Games
* [Game-Game](https://game-game.com/) - Browser Games
* [ArcadeSpot](https://arcadespot.com/) - Browser Games
* [Gaming Wonderland](https://www.gamingwonderland.com/) - Browser Games
* [Alfy](https://www.alfy.com/) - Browser Games
* [Andkon](https://andkon.com/arcade/) - Browser Games
* [FreeGames](https://freegames.org/) - Browser Games
* [Friv](https://www.friv.com/) - Browser Games
* [Emupedia](https://emupedia.net/beta/) - Browser Games
* [simmer.io](https://simmer.io/) - Unity Indie Browser Games
* [/r/WebGames](https://reddit.com/r/WebGames) - Browser Games Subreddit
* [Spatial](https://www.spatial.io/) - 3D Browser Games
* [Curated PICO-8](https://nerdyteachers.com/PICO-8/Games/) - PICO-8 Browser Games
* [Rosebud AI](https://www.rosebud.ai/) or [Wild West](https://www.wildwest.gg/) - AI Made Browser Games
* [Noel Friedrich](https://www.noel-friedrich.de/terminal/) - Browser Terminal Games
* [Unblock KISD](https://sites.google.com/view/unblockkisd/), [frogie's arcade](https://frogiesarca.de/), [Tyrone's Unblocked](https://sites.google.com/site/tyronesgamesez/) or [UBG365](https://ubg365.github.io/) - Browser Games / Unblocked at Schools
* [CoolMathGames](https://www.coolmathgames.com/) - Browser Game Site (disguised as edu games)
* [FlashMuseum](https://flashmuseum.org/), [Flash Arch](https://flasharch.com/en) or [AlbinoBlackSheep](https://www.albinoblacksheep.com/games/) - Flash Games
* [Arcade Prehacks](https://www.arcadeprehacks.com/) or [KongHack](https://konghack.com/) - Flash Game Mods
* [Js13kGames](https://js13kgames.com/entries), [HTML5 Games](https://html5games.com/) or [TheBestarcade](https://html5.thebestarcadescript.com/) - HTML5 Games
* [iogames.space](https://iogames.space/), [itch.io](https://graebor.itch.io/), [Kindanice](https://kindanice.itch.io/), [Jezzamon](https://jezzamon.itch.io/), [Modd.io](https://www.modd.io/) or [Kevin Games](https://kevin.games/) - .io Games

***

## ▷ Party / Multiplayer

* ⭐ **[Eaglercraft](https://eaglercraft.com/)** or [EaglerCraftX](https://fastest.eaglercraft.win/) - Online Browser Minecraft / [Note](https://github.com/fmhy/FMHY/wiki/FMHY%E2%80%90Notes.md#eaglercraft-note) / [Source](https://git.eaglercraft.rip/eaglercraft)
* ⭐ **[NetGames](https://netgames.io/)** - Multiple Games / [Discord](https://discord.com/invite/chgD7WF)
* ⭐ **[Codenames](https://codenames.game/)** - Party Card Games
* ⭐ **[GarticPhone](https://garticphone.com/)** - Telephone Game
* ⭐ **[Powerline.io](https://powerline.io/)** - Multiplayer Snake / [Discord](https://discord.com/invite/NckDSyb)
* ⭐ **[TagPro](https://koalabeast.com/)** - Multiplayer Capture the Flag / [Discord](https://discord.com/invite/hhW3MDzrt3)
* ⭐ **[skribbl](https://skribbl.io/)**, [DrawBattle](https://drawbattle.io/), [Sketchful](https://sketchful.io/), [Drawize](https://www.drawize.com/) or [Gartic](https://gartic.io/) - Drawing / Guessing Game / Multiplayer
* ⭐ **Eaglercraft Tools** - [Mod Loader](https://eaglerforge.github.io/) / [Mod Search](https://eaglerrinth.github.io/) / [Create Mods](https://eaglerforge-builder.vercel.app/) / [Public Servers](https://servers.eaglercraft.com/)
* ⭐ **[Make It Meme](https://makeitmeme.com/)** - Meme Party Game
* [Bloxd](https://bloxd.io/) or [MiniBlox](https://miniblox.io/) - Online Minecraft Clones
* [Bloob.io](https://bloob.io/) - Multiple Games
* [Gidd.io](https://gidd.io/) - Multiple Games
* [Yucata](https://www.yucata.de/en/) - Multiple Games
* [Foony](https://foony.com/) - Multiple Games
* [Pixoguess](https://pixoguess.io/) - Guess Pixelated Images
* [Tensor Trust](https://tensortrust.ai/) - AI Prompting Multiplayer Skill Game
* [Deeeep](https://deeeep.io/) - Multiplayer Feeding Frenzy Games
* [fsh.zone](https://fsh.zone/) - Multiplayer Fishing Game / [Discord](https://discord.com/invite/FKEzJSf)
* [Moo Moo](https://moomoo.io/) - Multiplayer Survival Game
* [Game Of Bombs](https://gameofbombs.com/) - Multiplayer Bomberman Style MMO
* [Gpop.io](https://gpop.io/) - Rhythm Game
* [Betrayal](https://betrayal.io/) - Among Us Clone
* [Death by AI](https://deathbyai.gg/) - Survival Plan Game
* [Territorial](https://territorial.io/) - Conquest / War Games
* [Smash Karts](https://smashkarts.io/) - Kart Battles
* [tix.tax](https://tix.tax/) - Tic-Tac-Toe

***

## ▷ Shooter

* ⭐ **[Play-CS](https://play-cs.com/)** - Browser Counter-Strike 1.6
* ⭐ **[NZP](https://nzp.gay/)** - Browser COD Zombies
* ⭐ **[Krunker.io](https://krunker.io/)**, [2](https://browserfps.com/) - PvP FPS
* [OpenArena Live](https://kosmi.io/openarena) - Quake 3 Arena Clone
* [WebLiero](https://www.webliero.com/) - Multiplayer Liero Clone
* [Venge](https://venge.io/) - PvP FPS
* [kour.io](https://kour.io/) - PvP FPS
* [Deadshot](https://deadshot.io/) - PvP FPS
* [LolShot](https://lolshot.io/) - PvP FPS
* [1v1.LOL](https://1v1.lol/) - 1v1 Building / Battle Simulator
* [ShellShock](https://www.shellshock.io/) - PvP FPS
* [MiniRoyale](https://miniroyale.io/) - Battle Royale Game
* [ZombsRoyale.io](https://zombsroyale.io/) - Top-Down Battle Royale
* [Gats.io](https://gats.io/) - Top-Down Battle Royale / [Discord](https://discord.gg/8Tspptdupm)
* [Wings.io](https://wings.io/) - Multiplayer Plane Battles / [Discord](https://discord.com/invite/HQcTbuZByA)
* [Operius](https://mors-games.itch.io/operius) - Space Shooter
* [Galaxies](https://playcanv.as/p/Ikq6Uk6A/) - Space Combat Game
* [Tanki](https://tankionline.com/) or [Diep](https://diep.io/) - Online Team VS Team Tank Games
* [webXash](https://x8bitrain.github.io/webXash/) - Half Life Demo

***

## ▷ Platformer

* ⭐ **[Bonk](https://bonk.io/)** - Multiplayer Physics Game
* ⭐ **[TotalJerkFace](https://totaljerkface.com/)** - Happy Wheels & Other Games
* ⭐ **[Line Rider](https://www.linerider.com/)** - Draw Sled Tracks
* [LOLBeans](https://lolbeans.io/) - Fall Guys Clone
* [Free Rider HD](https://www.freeriderhd.com/) - Draw / Race Bike Tracks
* [Raptjs](https://madebyevan.com/rapt/) or [Synesthesia in Space](http://synesthesiagame.com/) - Puzzle Platformer
* [Tales of Dorime](https://dorime.udany.net/) - 2D Platformer
* [PrinceJS](https://princejs.com/) - Prince of Persia

***

## ▷ Simulation

* [HatTrick](https://www.hattrick.org/) - Multiplayer Football Manager
* [FSHistory](https://s-macke.github.io/FSHistory/) - Play Classic Flight Simulator
* [Hacker Wars](https://hackerwars.io/) - Hacking Simulators
* [Startup Simulator](https://toggl.com/startup-simulator/) - Startup Simulation Game
* [Sim CB](https://benoitessiambre.com/macro.html) - Central Bank Simulator
* [Orbity](https://orbity.io/game.php) - Spaceship Launching Game
* [Plane Food Simulator](https://sheepandram.itch.io/pfs2021) - Plane Food Eating Game
* [Alternate History Simulator](https://abw.blue/) - Write Alternate History
* [NationStates](https://www.nationstates.net/) - Nation Simulation Game / [Scripts](https://hare.kractero.com/)
* [Politics and War](https://politicsandwar.com/) - More Advanced Nation Building Simulation Game / [Discord](https://discord.com/invite/H9XnGxc)
* [GeoFS](https://www.geo-fs.com/geofs.php) - Plane Simulator
* [Money Simulator](https://simulator.money) - Money Simulator
* [BrantSteele](https://brantsteele.net/) or [Simublast](https://www.simublast.com/) - Game Show Simulators

***

## ▷ RPG

* [Fallen London](https://www.fallenlondon.com/) - Text-Based RPG
* [Bit Heroes Arena](https://bitheroesarena.io/) - 8-bit RPG
* [Yume Nikki Online Project](https://ynoproject.net/) - Multiplayer Yume Nikki / [Discord](https://discord.com/invite/fRG3AxUeKN)
* [Dynast](https://dynast.io/) - Survival Browser Game
* [Kingdom of Loathing](https://www.kingdomofloathing.com/) - Comedy RPG
* [Frasier Fantasy](https://edward-la-barbera.itch.io/frasier-fantasy) - Comedy RPG
* [Gridland](https://gridland.doublespeakgames.com/) - Grid Matching RPG
* [Backpack Hero](https://thejaspel.itch.io/backpack-hero) - Turn-Based RPG
* [Miniconomy](https://www.miniconomy.com/) - Economy Game
* [Forumwarz](https://www.forumwarz.com/) - Browser RPG
* [Dungeon Crawl](https://crawl.develz.org/) - Browser RPG
* [Isleward](https://bigbadwaffle.itch.io/isleward) - Browser RPG

***

## ▷ Board / Card / Dice

* 🌐 **[Online Board Games](https://i.ibb.co/4Yzk4nV/Zb-Q2ste-L-o.png)** / [2](https://imgbox.com/ZbQ2steL/) - Board Game Index
* 🌐 **[Curlie Board Games](https://curlie.org/en/Games/Video_Games/Recreation/Browser_Based/Board_Games)** - Board Game Index
* 🌐 **[Curlie Cards](https://curlie.org/en/Games/Video_Games/Recreation/Browser_Based/Cards)** - Card Game Index
* 🌐 **[Curlie Yahtzee](https://curlie.org/en/Games/Video_Games/Recreation/Browser_Based/Dice/Yahtzee)** - Yahtzee Game Index
* ⭐ **[WorldOfCardGames](https://worldofcardgames.com/)**, [CardGames.io](https://cardgames.io/), [247Games](https://www.247games.com/), [CardzMania](https://www.cardzmania.com/) or [World of Solitaire](https://worldofsolitaire.com/) - Multiplayer Card Games
* [Board Game Online](https://www.boardgame-online.com/) - Online Board Games
* [Board Game Arena](https://en.boardgamearena.com/) - Online Board Games
* [Tabletopia](https://tabletopia.com/) - Online Board Games
* [FunNode](https://www.funnode.com/) - Online Board Games
* [Screentop](https://screentop.gg/) - Online Board Games / [Discord](https://discord.gg/wva8ebh)
* [PartyProject](https://char64.itch.io/partyproject) - Mario Party Style Multiplayer Game
* [BlackReds](https://blacksreds.com/) - Multiplayer Card Games
* [FlyOrDie](https://www.flyordie.com/) - Multiplayer Card Games
* [Playok](https://www.playok.com/) - Multiplayer Card Games
* [PlayingCards](https://playingcards.io/) - Multiplayer Card Games
* [Richup](https://richup.io/) - Monopoly-Style Board Game
* [Rally The Troops](https://www.rally-the-troops.com/) - Historical Board Games / [Discord](https://discord.gg/CBrTh8k84A)
* [PictureCards](https://picturecards.online/) / [Discord](https://discord.gg/kJB4bxSksw), [AllBad.Cards](https://bad.cards/) or [Pretend You're](https://pyx-1.pretendyoure.xyz/zy/game.jsp) - Cards Against Humanity Online
* [Cards Against Humanity](https://www.cardsagainsthumanity.com/#downloads) - Printable Cards Against Humanity
* [Wikidata Card Game Generator](https://cardgame.blinry.org/) - Generate "Top Trumps" Cards with Wikidata
* [Solitaired](https://solitaired.com/), [Solitr](https://www.solitr.com/) or [Solitaire Owl](https://solitaireowl.com/) - Online Solitaire
* [PySolFC](https://pysolfc.sourceforge.io/) - Downloadable Solitaire / [GitHub](https://github.com/shlomif/PySolFC)
* [Blackjack Break](https://blackjackbreak.com/) or [HTML5 Blackjack](https://www.html5blackjack.net/) - Browser Blackjack
* [Poker Now](https://www.pokernow.club/) or [247 Free Poker](https://www.247freepoker.com/) - Multiplayer Poker
* [KDice](https://www.kdice.com/) - Multiplayer Dice War
* [Colonist](https://colonist.io/) - Multiplayer Settlers of Catan
* [Hexxagon](https://hexxagon.com/) - Hexagonal Board Game
* [The Bafflement Fires](https://www.dpoetry.com/fires/) - 1950s Freemasonic Board Game
* [Scorecard.gg](https://scorecard.gg/) - Board Game Scorecards

***

## ▷ Strategy

* ↪️ **[Chess Learning Resources](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/edu#wiki_.25B7_chess)**
* ⭐ **[lichess](https://lichess.org/)**, [GameKnot Chess](https://gameknot.com/), [SparkChess](https://www.sparkchess.com/) or [Chess.com](https://www.chess.com/) - Chess Platforms
* ⭐ **lichess Tools** - [Mobile](https://lichess.org/mobile) / [Mobile V2](https://play.google.com/store/apps/details?id=org.lichess.mobileV2) / [Customize](https://prettierlichess.github.io/) / [Themes](https://github.com/algertc/prettierlichess-themes) / [Leagues](https://www.lichess4545.com/) / [Extend](https://lichess.org/page/extend)
* ⭐ **[Print Chess](https://www.printchess.com/)** - Printable Paper Chess Set
* ⭐ **[Super Auto Pets](https://teamwood.itch.io/super-auto-pets)** - Pet Battle Game / [Resources](https://www.groundedsap.co.uk/)
* [Mah-Jongg](https://www.mahjongfun.com/), [Mahjong4Friends](https://mahjong4friends.com/), [Classic Mahjong](https://classic-mahjong.com/) or [The Mahjong](https://themahjong.com/) - Mahjong Games
* [lishogi](https://lishogi.org/) - Shogi
* [Online GO](https://online-go.com/) - Multiplayer GO
* [Warzone](https://www.warzone.com/) - RISK Clone
* [Neptune's Pride](https://np4.ironhelmet.com/) - Space Strategy Game
* [generals.io](https://generals.io/) - War Strategy Game
* [Chesses](https://pippinbarr.com/chesses/) or [Omnichess](https://omnichess.club/) - Multiple Styles of Chess
* [Echo Chess](https://echochess.com/) - Morph Style Chess / [Discord](https://discord.gg/echochess)
* [The Kilobyte's Gambit](https://vole.wtf/kilobytes-gambit/) - 1k Chess Game
* [Kung Fu Chess](https://www.kfchess.com/) - Real-Time Chess without Turns
* [PokemonChess](https://pokemonchess.com/) - Pokémon Style Chess / [Discord](https://discord.gg/fp5bcCqg8q)
* [Laser](https://playlaser.xyz/) - Alt Style Chess
* [Chess Base](https://www.chessbase.in/) / [2](https://en.chessbase.com/) - Indian Chess News
* [Lidraughts](https://lidraughts.org/) - Multiplayer Checkers

***

## ▷ Puzzle Games

* ⭐ **[Rubik's Cube Explorer](https://iamthecu.be/)**, [Grubiks](https://www.grubiks.com/), [pCubes](https://twistypuzzles.com/forum/viewtopic.php?f=1&t=27054) or [The Cube](https://bsehovac.github.io/the-cube/) - Rubix Cubes / [Guide](https://easiestsolve.com/) / [Solver](https://rubiksolve.com/), [2](https://rubiks-cube-solver.com/) / [Timer](https://cstimer.net/)
* ⭐ **[Minesweeper.online](https://minesweeper.online/)** - Minesweeper
* [Simon Tatham's Puzzles](https://www.chiark.greenend.org.uk/~sgtatham/puzzles/) - Multiple Puzzle Games / [Mobile](https://github.com/chrisboyle/sgtpuzzles)
* [Puzzle Party](https://artsandculture.google.com/experiment/puzzle-party/EwGBPZlIzv0KRw) - Multiplayer Jigsaws
* [PuzzlePrime](https://www.puzzleprime.com/) - Problems / Puzzles
* [Regex Crossword](https://regexcrossword.com/) - Regex Crosswords
* [Web Paint-by-Number](https://webpbn.com/) or [Nonograms](https://www.nonograms.org/) - Graphic Crosswords
* [Game for the Brain](https://www.gamesforthebrain.com/) - Puzzles / Quizzes
* [MasasGames](https://masasgames.com/) - Virtual Escape Rooms
* [Murdle](https://murdle.com/) - Daily Murder Mystery
* [Sokoban Online](https://www.sokobanonline.com/) - Sokoban Puzzles
* [DailyDungeon](https://dailydungeon.net/) - Puzzle Dungeon Crawler
* [Sokoban](https://suppilulemur.neocities.org/) - Zelda-Themed Sokoban Puzzles
* [All The 2048](https://true65536.github.io/allthe2048/), [DuckDuckgo 2048](https://duckduckgo.com/?q=play+2048&amp;ia=answer) or [2048](https://play2048.co/) - 2048 Puzzles
* [JetHolt](https://jetholt.com/hacking/), [RebelWithoutACause](https://rebelwithoutarootcause.com/demos/terminal/) or [Aramor](http://aramor.epizy.com/fallout-terminal/main) - Fallout Terminal Hacking Game
* [mmmines!](https://mmmines.fly.dev/), [MineJD](https://minesjd.com/) or [m3o](https://play.m3o.xyz/) - Multiplayer Minesweeper
* [Minesweeper Infinity](https://www.minesweeperinfinity.com/) - Infinte Minesweeper
* [Minesweeper Twist](https://polyreplay.com/minesweepertwist) - Irregular Grid Minesweeper
* [PROXX](https://proxx.app/) - Space Minesweeper
* [Rockbasher](https://www.rockbasher.com/) - Retro Style Puzzle Game
* [Orion](https://orion.lukasbach.com/) - Puzzle Game
* [Euclidea](https://www.euclidea.xyz/) - Geometric Puzzles
* [Pixel Puzzler](https://pixel-puzzler.playcurious.games/) or [UnFlip](https://unflipgame.com/) - Block Puzzles
* [Sudoku XV](https://keeri.place/sudoku-xv) - Sudoku
* [picture dots](https://www.picturedots.com/) - Make & Play Dot Puzzles
* [Oh, My Dots!](https://www.ohmydots.com/) - Connect the Dots Game
* [BreakLock](https://maxwellito.github.io/breaklock/) - Pattern Lock Game
* [Kuku Kube](https://kuku-kube.com/) - Find the Different Squares
* [MazeGenerator](https://www.mazegenerator.net/), [Maze Toys](https://maze.toys/) or [Maze](https://www.epgsoft.com/maze/) - Maze Generators

***

## ▷ Incremental / Idle

* 🌐 **[/r/Incremental_Games](https://www.reddit.com/r/incremental_games/wiki/list_of_incremental_games)**, [Galaxy Click](https://galaxy.click/), [Incremental Game Plaza](https://plaza.dsolver.ca/), [IncrementalDB](https://www.incrementaldb.com/) or [Almost Idle](https://almostidle.com/) - Incremental Games Indexes
* ⭐ **[Cookie Clicker](https://orteil.dashnet.org/cookieclicker/) / [2](https://orteil.dashnet.org/experiments/cookie/)** - Incremental Cookie Game
* ⭐ **Cookie Clicker Tools** - [Multiple Tools](https://github.com/CookieMonsterTeam/CookieMonster) / [Calculator](https://coderpatsy.bitbucket.io/cookies/cookies.html) / [Discord](https://discord.com/invite/cookie)
* [The Thorp of Woodstock](https://cheerfulghost.github.io/civ-clicker/index.html) - Build a Civilization
* [Universal paperclips](https://www.decisionproblem.com/paperclips/index2.html) - A Paperclip Creation Simulator
* [MousePoint](https://creativetechguy.com/mousepoint) - Incremental Mouse Movement Game
* [BitBurner](https://bitburner-official.github.io/) - Incremental RPG
* [CandyBox](https://candybox2.github.io/) - Candy Eating Game
* [Particle Clicker](https://particle-clicker.web.cern.ch/) - Incremental Particle Physics Games
* [KittensGame](https://kittensgame.com/web/) - Incremental Kitten Maker
* [Incremancer](https://incremancer.gti.nz/) or [Danemancer](https://cirusdane.github.io/incremancer/) - Incremental Zombie Game
* [A Dark Room](https://adarkroom.doublespeakgames.com/) - Dark Room Survival Game
* [The Fed](https://thefed.app/) - Incremental Banking Game
* [WarClicks](https://warclicks.com/) - Incremental War Game
* [Goblin Bet](https://goblin.bet/) - Bet on 1v1 Monster Fights
* [The First Alkahistorian](https://nagshell.github.io/elemental-inception-incremental/) - Incremental Elemental Game
* [FactoryIdle](https://factoryidle.com/) - Factory Idle Simulator
* [Idlescape](https://www.play.idlescape.com/) - Idle MMORPG
* [ProgressQuest](http://progressquest.com/) - Idle RPG
* [Anti Matter Dimesions](https://ivark.github.io/) - Anti Matter Idle Game
* [Theory of Magic](https://mathiashjelm.gitlab.io/arcanum/) - Magic Idle Game
* [Succubox](https://www.glaielgames.com/succubox/) - Loot Box Idle Game
* [Swarm Simulator](https://www.swarmsim.com/) - Idle Bug Swarm Game

***

## ▷ Trivia Games

* ⭐ **[GuessTheGame](https://guessthe.game/)** or [Gamedle](https://www.gamedle.wtf/) - Game Guessing Games
* ⭐ **[Free Rice](https://freerice.com/)** - Earn Rice for the World Food Programme / Trivia
* [Fun Trivia](https://www.funtrivia.com/), [Sporcle](https://www.sporcle.com/), [uQuiz](https://uquiz.com/), [ARealMe](https://www.arealme.com/) or [JetPunk](https://www.jetpunk.com/) - Quiz / Trivia
* [The Re-Ride](https://thereri.de/) - You Don't Know Jack: The Ride Remake / [Discord](https://discord.com/invite/89sgMHnDRB)
* [FlightGuesser](https://flightguesser.com/) - Flight Path Guessing Game
* [Akinator](https://en.akinator.com/) - 20 Questions
* [Buzzinga](https://buzzinga.io/) - Jeopardy Creator
* [Bestiefy](https://bestiefy.com/) - Friend Quizzes
* [WTM](https://whatthemovie.com/), [Moviedle](https://moviedle.xyz/), [Actorle](https://actorle.com/), [Kino.wtf](https://www.kino.wtf/), [Likewise](https://likewise.com/), [Flickle](https://flickle.app/) or [Framed](https://framed.wtf/) - Movie Guessing Games
* [Cinenerdle](https://www.cinenerdle.app/) or [Cinenerdle2](https://www.cinenerdle2.app/) - Movie Puzzles
* [BoxOfficeGA](https://boxofficega.me/) - Box Office Guessing
* [Scenewise](https://scenewise.io/) - Movie Scene Order Puzzle
* [Actorle TV](https://actorle.tv/) - TV Show Guessing
* [GuessAnimeQuiz](https://guessanimequiz.com/) - Anime Guessing
* [AMQ](https://animemusicquiz.com/) - Anime Theme Guessing
* [ConnectTheStars](https://connectthestars.xyz/) or [Movie To Movie](https://movietomovie.com/) - Connect Stars through Movies
* [Play Football](https://playfootball.games/) - Football Quizzes / Trivia
* [The Wiki Game](https://www.thewikigame.com/), [Pedantle](https://cemantle.certitudes.org/pedantle), [Six Degrees of Wikipedia](https://www.sixdegreesofwikipedia.com/) or [WikiRacer](https://wikiracer.io/) - Wiki Exploration Games / [Automation Tool](https://gitlab.com/johanbluecreek/wikiracer)
* [Catfishing](https://catfishing.net/) - Wiki Article Guessing Game
* [MusicNerd](https://musicnerd.io/) or [Lofidle](https://lofidle.com/) - Music Guessing Games
* [More or Less](https://moreorless.io/) - More or Less Guessing
* [DanceMusic](https://dancemusic.wtf/) - Electronic Music Genre Guessing Game
* [Guess My Rank](https://guessmyrank.com/) - Guess Player Game Ranks
* [Poeltl](https://poeltl.nbpa.com/) - NBA Guessing Game
* [The Higher Lower Game](https://www.higherlowergame.com/) or [Google Feud](https://googlefeud.com/) - Guess What's Googled More
* [Graphs](https://www.graphs.world/) - Graph Guessing Game
* [English Sandwhich](https://englishsandwich.github.io/) - Guess Where Dishes are From
* [Guess The Price](https://guesstheprice.net/) - Price Guessing Game
* [Apparle](https://www.apparle.com/) - Apparel Price Guessing Game
* [Metazooa](https://metazooa.com/) - Animal Guessing Game
* [Pufferdle](https://pufferdle.com/) - Fish Guessing Game
* [ChessGuessr](https://www.chessguessr.com/) - Chess Style Guessing Game
* [Huedle](https://huedle.com/), [Color Rush](https://www.colorrush.io/) or [Hexcodle](https://www.hexcodle.com/) - Hex Code Guessing Games
* [Nerdle](https://nerdlegame.com/), [Additional](https://additional.today/) or [Countle](https://www.countle.org/) - Math Guessing Games
* [Minecraftle](https://minecraftle.zachmanson.com/) - Minecraft Recipe Guessing Game
* [PkmnQuiz](https://pkmnquiz.com/), [Gearoid Pokémon](https://gearoid.me/pokemon/), [Pokedle](https://pokedle.net/) or [Squirdle](https://squirdle.fireblend.com/) - Pokémon Guessing Games
* [LoLdle](https://loldle.net/) - League of Legends Guessing Games
* [Owdle](https://owdle.guessing.day/) - Overwatch Guessing Games
* [Teuteuf](https://teuteuf.fr/) - Geography Guessing Games
* [Guess The Year](https://guess-the-year.davjhan.com/) or [ChronoPhoto](https://www.chronophoto.app/) - Year Guessing Game
* [Wikitrivia](https://wikitrivia.tomjwatson.com/) - Guess Which Event Came First
* [Human or Not?](https://www.humanornot.ai/) - Guess Human vs. AI

***

## ▷ GeoGuessr Games

* ⭐ **[Geotastic](https://geotastic.net/)** - Multiplayer GeoGuessr / Account Required
* ⭐ **[Globle](https://globle-game.com/)** - Country Hot-or-Cold Guessing Game
* [Emily's GeoGuessr Tools](https://geo.emily.bz/) - GeoGuessr Tools
* [GeoTips](https://geotips.net/) / [Discord](https://discord.gg/svhWzU7FMa), [GeoHints](https://geohints.com/) / [Discord](https://discord.gg/bCZ8Bg2vUd), [Plonk It](https://www.plonkit.net/) or [Top Tricks](https://somerandomstuff1.wordpress.com/2019/02/08/geoguessr-the-top-tips-tricks-and-techniques/) - GeoGuessr Guides / Tips
* [Geohub](https://www.geohub.gg/) - Free GeoGuessr Alt / Requires Google API
* [GuessWhereYouAre](https://guesswhereyouare.com/) - Free GeoGuessr Alt w/ Multiplayer
* [OpenGuessr](https://openguessr.com/) - Free GeoGuessr Alt w/ Multiplayer
* [WorldGuessr](https://www.worldguessr.com/) - Free GeoGuessr Alt
* [City Guesser](https://virtualvacation.us/guess) - Video-Based GeoGuessr
* [Quizzity](https://david-peter.de/quizzity/) - City Guessing Game
* [Tradle](https://games.oec.world/en/tradle/) - Guess Countries by their Exports
* [Back Of Your Hand](https://backofyourhand.com/) - Local GeoGuessr
* [LostGamer](https://lostgamer.io/) - Video Game GeoGuessr
* [GTA V GeoGuesser](https://gta-geoguesser.com/) - GTA V GeoGuessr
* [TimeGuessr](https://timeguessr.com/) - Historical Time-period GeoGuessr
* [LanguageGuessr](https://languageguessr.io/) - Language GeoGuessr
* [Artifact Guesser](https://artifactguesser.com/) or [GeoArtwork](https://artsandculture.google.com/experiment/geo-artwork/wgEPVBAUiRVlEQ) - Guess Origins of Cultural Artifacts
* [travle](https://travle.earth/) - Guess Countries Between Two Locations
* [MapGenerator](https://map-generator-nsj.vercel.app/) - GeoGuessr Map Generator

***

## ▷ Word Games

* 🌐 **[Awesome Wordle](https://github.com/prakhar897/awesome-wordle)**, [Wordles of the World](https://rwmpelstilzchen.gitlab.io/wordles/) or [Wordleverse](https://wordleverse.net/games) - Wordle Game Index
* ⭐ **[Wordle](https://www.nytimes.com/games/wordle/index.html)** - Original Wordle
* ⭐ **[Wordle Analyzer](https://wordle-analyzer.com/)**
* ⭐ **[BestCrosswords](https://www.bestcrosswords.com/)**, [TheWordSearch](https://thewordsearch.com/) or [Regex-Crossword](https://jimbly.github.io/regex-crossword/) - Crossword Puzzles / [Creator](https://puzzlemaker.discoveryeducation.com/), [2](https://www.xwords-generator.de/en) / [Solver](https://www.wordplays.com/), [2](https://www.dictionary.com/e/crosswordsolver/), [3](https://crossword-solver.io/)
* ⭐ **[KillerCrossword](https://killercrossword.com/)** - No Clue Crosswords
* ⭐ **[MoreWords](https://www.morewords.com/)**, [PlayScrabble](https://playscrabble.com/) or [WordHub](https://wordhub.com/) - Scrabble
* [MakeAWordSearch](http://www.makeawordsearch.net/) - Word Search Creator
* [Connections](https://connections.swellgarfo.com/) - Custom Word Puzzles
* [RobinWords](https://www.robinwords.com/) - Word Ladder Game
* [Word Golf](https://www.word.golf/) - Word Relation Game
* [Truncate](https://truncate.town/) - Crossword Strategy Game
* [HoverCats](https://hovercats.gg/) - Multiplayer Crosswords
* [JKLM.FUN](https://jklm.fun/) - Multiplayer Word Games
* [eWordChallenge](https://www.ewordchallenge.net/) - Boggle Online
* [Squaredle](https://squaredle.app/) - Daily Word Puzzle
* [Linxicon](https://linxicon.com/) - Word Connection Game
* [Wordle VS](https://wordlevs.com/) - Multiplayer Wordle
* [Wordle Unlimited](https://wordleunlimited.org/) - Wordle without Daily Limit
* [Fusele](https://fusele.netlify.app/) - Wordle Variant
* [Word500](https://word500.com/) - Wordle + Mastermind
* [Wordly](https://wordly.org/) - Wordle Clone
* [Octordle](https://www.britannica.com/games/octordle/) - Eight Word Wordle
* [Sqword](https://www.sqword.com/) - Deck-Based Wordle
* [Alphabeticle](https://alphabeticle.xyz/) - Alphabetical Wordle
* [WordMaze](https://wordmaze.click/) - Maze Style Wordle
* [Pixletters](https://pixletters.com/) - Pixel Style Wordle
* [Wourdle](https://wourdle.com/) - British English Wordle
* [Ridella](https://ridella.xyz/) - Riddle Wordle

***

# ► [Gaming Tools](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/game-tools)
