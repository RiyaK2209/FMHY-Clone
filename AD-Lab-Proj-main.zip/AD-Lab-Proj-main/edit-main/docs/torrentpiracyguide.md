***
***
***
***

# ► Torrent Sites

**Warning** - It's best to avoid sites that allow anyone to make accounts when getting both software and games. Avoid sites and uploaders listed on the [Unsafe Sites](https://fmhy.net/unsafesites) page.

***

* ⭐ **[RuTracker](https://rutracker.org/)**, [2](https://rutracker.net/) - Video / Audio / Comics / Magazines / Signup Required
* ⭐ **RuTracker Tools** - [Addon](https://addons.mozilla.org/en-US/firefox/addon/rutracker_torrent_search/) / [Wiki](http://rutracker.wiki/) / [Rules](https://rutracker.org/forum/viewtopic.php?t=1045) / [Translator](https://github.com/FilipePS/Traduzir-paginas-web#install)
* ⭐ **[m0nkrus](https://w16.monkrus.ws/)** / [2](https://vk.com/monkrus) - Adobe Software Archive / [Block Adobe](https://rentry.co/FMHYBase64#a-dove-is-dumb) / [Search](https://monkrus.dvuzu.com/) / [Telegram](https://t.me/real_monkrus)
* ⭐ **[Torrent CSE](https://cse.google.com/cse?cx=006516753008110874046:0led5tukccj)** / [CSE 2](https://cse.google.com/cse?cx=006516753008110874046:kh3piqxus6n) - Multi Site Search
* [1337x](https://1337x.to/) - Video / Audio / NSFW
* 1337x Tools - [Mirrors](https://1337x-status.org/), [2](https://1337x.to/about), [3](https://ibb.co/py0RCz9) / [User Ranks](https://i.ibb.co/WfNhvtB/ebc2def26433.png) / [Telegram Bot](https://t.me/search_content_bot), [2](https://github.com/xbIm/1337x-torrent-telegram-bot) / [IMDb Ratings](https://github.com/kotylo/1337imdb) / [Proxy](https://redd.it/tz7nyx), [2](https://pastebin.com/3n5K0QrP) / [.onion](http://l337xdarkkaqfwzntnfk5bmoaroivtl6xsbatabvlb52umg6v3ch44yd.onion/) / [Magnets](https://greasyfork.org/en/scripts/373230) / [Timezone Fix](https://greasyfork.org/en/scripts/421635)
* [RARBG Dump](https://rarbgdump.com/) - Video / Audio / Games / Books / NSFW / Continuation Project
* [LimeTorrents](https://www.limetorrents.lol/) - Video / Audio / Books
* [IsoHunt](https://isohunts.to/) - Video / Audio / Books
* [TorrentDownloads](https://www.torrentdownloads.pro/) - Video / Audio / Books
* [ExtraTorrent](https://extratorrent.st/) - Video / Audio / Books / NSFW
* [rutor.info](https://rutor.info/) or [rutor.is](https://rutor.is/) - Video / Audio / Books / ROMs / Magazines / Use [Translator](https://github.com/FilipePS/Traduzir-paginas-web#install)
* [NNM-Club](https://nnmclub.to/) - Video / Audio / [Note](https://i.ibb.co/MPRttDC/6a35c3c79cde.png)
* [Torrenting](https://www.torrenting.com/) - Video / Audio / Books / NSFW / Signup Required
* [ZeroTorrent](http://127.0.0.1:43110/ZeroTorrent.bit/), [2](https://proxy.zeronet.dev/ZeroTorrent.bit/) - [ZeroNet Required](https://zeronet.io/) / Video / Audio
* [4chan /t/](https://boards.4chan.org/t/) - Torrents / Imageboard / Some NSFW

***

## ▷ Aggregators

**Warning** - Aggregators include many sources, so it's best to avoid using them for software and games. Avoid sites and uploaders listed on the [Unsafe Sites](https://www.reddit.com/r/FREEMEDIAHECKYEAH/comments/10bh0h9/unsafe_sites_software_thread/) page.

***

* ⭐ **[BTDigg](https://btdig.com/)** - DHT-Based / [.onion](http://btdigggink2pdqzqrik3blmqemsbntpzwxottujilcdjfz56jumzfsyd.onion/) / [.i2p](http://btdigg.i2p/)
* ⭐ **[BitSearch](https://bitsearch.to/)**, [2](https://solidtorrents.to) - DHT-Based
* ⭐ **[Knaben](https://knaben.org/)**
* [ExT](https://ext.to/), [2](https://search.extto.com/) / [Proxy](https://extranet.torrentbay.st/)
* [TorrentProject](https://torrentproject.cc/), [2](https://torrentproject2.net/) - DHT-Based
* [DaMagNet](https://damag.net/) - DHT-Based
* [TorrentDownload](https://www.torrentdownload.info/)
* [TorrentQuest](https://torrentquest.com/)
* [TorrentCORE](https://torrentcore.xyz/)
* [Cleanbay](https://cleanbay.netlify.app/)
* [CloudTorrents](https://cloudtorrents.com/)
* [Torrents-CSV](https://torrents-csv.com/)
* [FileMood](https://filemood.com/)
* [iDope](https://idope.se/)
* [BT4G](https://bt4gprx.com/)
* [PiratesParadise](https://piratesparadise.org/)
* [snowfl](https://snowfl.com/)
* [Torlock](https://www.torlock.com/)
* [YourBittorrent](https://yourbittorrent.com/)
* [BTSearch](https://btsearch.19950817.xyz/en)
* [0Mag](https://www.0mag.net/), [2](https://16mag.net/) - Magnet Link Sharing Platform
* [Magnetissimo](https://github.com/sergiotapia/magnetissimo) - Magnet Search Web App
* [TorrentSearchRobot](https://t.me/TorrentSearchRoBot) or [TorrentHuntBot](https://t.me/torrenthuntbot) - Telegram Torrent Search Bots
* [Torrentinim](https://github.com/sergiotapia/torrentinim) or [BitMagnet](https://bitmagnet.io/) - Self-Hosted Torrent Search Engines

***

## ▷ [Video Sites](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/video#wiki_.25BA_torrent_sites)

***

## ▷ [Anime Sites](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/video#wiki_.25B7_anime_torrenting)

***

## ▷ [Educational Sites](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/edu#wiki_.25BA_torrenting)

***

## ▷ [Game Sites](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/games#wiki_.25BA_download_games)

***

## ▷ [Audio Sites](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/audio#wiki_.25BA_audio_torrenting)

***

# ► Torrent Clients

**Warning** - Make sure you [BIND](https://redd.it/ssy8vv) your [VPN](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/adblock-vpn-privacy#wiki_.25BA_vpn) to your client to avoid ISP letters.

***

* ⭐ **[qBittorrent](https://www.qbittorrent.org/)** or [QBT Enhanced](https://github.com/c0re100/qBittorrent-Enhanced-Edition) - [Tools](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/torrent#wiki_.25B7_qbittorrent_tools)
* ⭐ **[Deluge](https://www.deluge-torrent.org/)** - [Plugins](https://deluge-torrent.org/plugins/) / [Config](https://github.com/ratanakvlun/deluge-ltconfig/releases) / [Telegram Plugin](https://github.com/noam09/deluge-telegramer)
* ⭐ **[Transmission](https://transmissionbt.com/)**
* [torrent-control](https://github.com/Mika-/torrent-control) or [Remote Torrent Adder](https://github.com/bogenpirat/remote-torrent-adder) - Easily Send Torrents to Client
* [imFile](https://imfile.io/) / Updated Motrix fork / [GitHub](https://github.com/imfile-io/imfile-desktop) 
* [Tixati](https://tixati.com/)
* [WizTorrent](https://wiztorrent.com/) / Torrent Player / WebShare
* [BiglyBT](https://www.biglybt.com/)
* [LIII](https://codecpack.co/download/LIII-BitTorrent-Client.html)
* [PikaTorrent](https://www.pikatorrent.com/) / [GitHub](https://github.com/G-Ray/pikatorrent)
* [Distribyted](https://distribyted.com/) / [GitHub](https://github.com/distribyted/distribyted)
* [Instant.io](https://instant.io/) - Stream Torrents in Browser
* [BTorrent](https://btorrent.xyz/) - Stream Torrents in Browser
* [Magnet Player](https://ferrolho.github.io/magnet-player/) - Stream Torrents in Browser
* [BitFord](https://github.com/astro/bitford) - Chrome
* [Rats Search](https://github.com/DEgITx/rats-search) - Torrent Search Client
* [Download Torrents Through I2P](https://decentnet.github.io/blog/20200329-download-torrents-through-i2p.html)
* [flood](https://flood.js.org/) - rTorrent, Transmission & qBittorrent WebUI / [GitHub](https://github.com/jesec/flood)
* [/r/Seedboxes](https://www.reddit.com/r/seedboxes/) - Seedbox Subreddit
* [Seedbox Guide](https://seedboxgui.de/seedbox/) - Seedbox Comparisons

***

## ▷ qBittorrent Tools

* 🌐 **[QBT Plugins](https://github.com/qbittorrent/search-plugins?tab=readme-ov-file#search-plugins)** - Plugins Index
* 🌐 **[QBT Themes](https://github.com/qbittorrent/qBittorrent/wiki/List-of-known-qBittorrent-themes)** - Themes Index
* [qBitMF](https://github.com/qBitMF/qBitMF) - Multi-Connection Tool
* [VueTorrent](https://github.com/VueTorrent/VueTorrent) - Web Client
* [rqBit](https://github.com/ikatson/rqbit/) - Rust Client
* [qBit Manage](https://github.com/StuffAnThings/qbit_manage) - Manager / Automation Tool
* [qBitController](https://github.com/Bartuzen/qBitController) - Mobile Controllers
* [Docker QBT](https://github.com/linuxserver/docker-qbittorrent) or [QBT VPN](https://github.com/binhex/arch-qbittorrentvpn) - Docker Builds
* [QBT Mega](https://colab.research.google.com/github/Xavy-13/qbittorrent/blob/main/qBittorrent_MEGA.ipynb) - Mega Upload Script
* [QBT Google Drive](https://colab.research.google.com/github/Xavy-13/qbittorrent/blob/main/qBittorrent.ipynb) - Google Drive Upload Script
* [Dark Theme](https://draculatheme.com/qbittorrent) or [iOS Style](https://github.com/ntoporcov/iQbit/) - QBT Themes
* [qBitEndpoints](https://rentry.co/qBitEndpoints) - API Endpoints
* [Quantum](https://github.com/UHAXM1/Quantum) - Auto Port Updater for Proton

***

## ▷ Remote Torrenting

* ↪️ **[Torrent to Google Drive](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/storage#wiki_torrent_to_google_drive)**
* ⭐ **[Seedr](https://www.seedr.cc/)** - [Telegram Bot](https://t.me/TorrentSeedrBot) / [API Wrapper](https://github.com/theabbie/seedr-api), [2](https://github.com/AnjanaMadu/SeedrAPI) - Torrent to Cloud and Stream
* [webtor](https://webtor.io/) - Torrent to Stream / DDL Sites
* [Multi-Up](https://multiup.io/en/upload/from-torrent) - Torrent to DDL Sites
* [Bitport](https://bitport.io/welcome) - Torrent to Cloud and Stream
* [TorrentSafe](https://www.torrentsafe.com/) - Torrent to Cloud and Stream
* [ZBIGZ](https://zbigz.com/) - Torrent to Cloud and Stream
* [Demagnetize](http://demagnetize.link/) - Torrent to DDL

***

## ▷ [Android Clients](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/android#wiki_.25BA_android_torrenting)

***

# ► Tracker Invites

* 🌐 **[Private Trackers General](https://rentry.co/private-trackers)**, **[/r/TrackersInfo](https://www.reddit.com/r/TrackersInfo/wiki/official_recruitments/)**, [The Sheet](https://inviteroute.github.io/sheet/), [Graph](https://inviteroute.github.io/graph/) or [InstallGentoo](https://igwiki.lyci.de/wiki/Private_trackers) - Private Tracker Guides
* 🌐 **[Scene Related](https://opentrackers.org/links/warez-scene/#scenerelated)** - Warez / Scene Site Index
* ⭐ **[TrackerStatus](https://trackerstatus.info/)** or [TrackerHub](https://hdvinnie.github.io/TrackerHub/) - Tracker Status Updates
* [/r/trackers](https://reddit.com/r/trackers) - Tracker Discussion
* [/r/OpenSignups](https://www.reddit.com/r/OpenSignups/) or [/r/OpenedSignups](https://www.reddit.com/r/OpenedSignups/) - Open Tracker Signup Subs
* [MyAnonaMouse](https://www.myanonamouse.net/) - Open Applications
* [hdvinnie](https://hdvinnie.github.io/Private-Trackers-Spreadsheet/) - Private Tracker List
* [OpenSignups](https://t.me/trackersignup) - Open Signups Private Trackers / Telegram
* [Upload-Assistant](https://github.com/L4GSP1KE/Upload-Assistant) - Private Tracker Auto-Upload
* [TrackerScreenshot](https://github.com/KlevGG/TrackerScreenshot) - Auto Screenshot Tracker Stats

***

# ► Helpful Sites / Apps

* 🌐 **[ngosang](https://ngosang.github.io/trackerslist/)** / [2](https://ngosang.github.io/trackerslist/trackers_all.txt) / [3](https://github.com/ngosang/trackerslist), [trackerslist](https://trackerslist.com/) / [GitHub](https://github.com/XIU2/TrackersListCollection) or [NewTrackOn](https://newtrackon.com/list) - Tracker Lists
* 🌐 **[Auto Torrent Tools List](https://redd.it/hbwnb2)** / [2](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/video#wiki_.25BA_torrent_apps)
* ⭐ **[Milkie](https://milkie.cc)** / [Discord](https://discord.com/invite/E4khNy5dz3) or [Scnlog](https://scnlog.me) - Scene Release Download
* ⭐ **[PreDB.net](https://predb.net/)**, **[PreDataBA](https://predataba.se)**, [Xrel](https://www.xrel.to), [PreDB.me](https://predb.me), [NGP](https://ngp.re/), [Archiv.pw](https://archiv.pw/), [PreDB.org](https://predb.org/), [srrDB](https://www.srrdb.com) or [M2V](https://m2v.ru) - Scene Release Info
* ⭐ **[T2M](https://nutbread.github.io/t2m/)** / [2](https://github.com/nutbread/t2m), [btsow](https://btsow.motorcycles/) or [Torrent Kitty](https://www.torrentkitty.tv/) / [2](https://www.torrentkitty.net/) / [3](https://www.torrentkitty.lol/) - Torrent to Magnet Converters
* ⭐ **[Magnet2Torrent](https://magnet2torrent.com/)** - Magnet to Torrent Converter
* ⭐ **[Torrent Legality](https://i.ibb.co/HHqC4V2/11e244ddbdfb.png)** - Torrenting Laws by Country
* [PeerBanHelper](https://github.com/PBH-BTN/PeerBanHelper/blob/master/README.EN.md) - Block Unwanted Leeches / Peers
* [btcache](https://btcache.me/), [iTorrents](https://itorrents.org) or [Torrage](https://torrage.info/) - Torrent Storage Cache
* [InfoTorrent](https://infotorrent.tnl.one/) or [Webtorrent Checker](https://checker.openwebtorrent.com/) - Check Torrent File Health
* [TorrentTags](https://torrenttags.com/) - Check Torrents for Copyright Claims
* [MagLit](https://maglit.me/) - Magnet Link Shorteners / [GitHub](https://github.com/NayamAmarshe/thiss.link)
* [Magnet Link Generator](https://magnetlinkgenerator.com/) - Magnet Link Generator
* [magnet2list](https://hutstep.github.io/magnet2list/) - Convert Magnets to Tracker Lists
* [OpenWebTorrent](https://openwebtorrent.com/) - Free Webtorrent Tracker
* [AutoDL-Irssi](https://autodl-community.github.io/autodl-irssi/) - IRC Channel Monitor / Autodownload / [Slack Notifications](https://gist.github.com/Igglybuff/00d5e91274a562ac724d358bbbc8bc7b)
* [PrivTracker](https://privtracker.com/) - Private BitTorrent Tracker Generator / [GitHub](https://github.com/meehow/privtracker)
* [AnonSeed](https://www.anonseed.com/) - Anonymous Torrent Sharing
* [Torrent-Creator](https://github.com/Kimbatt/torrent-creator) - Browser Torrent Creator
* [Torrent Parts](https://torrent.parts/) or [Torrent File Editor](https://torrent-file-editor.github.io/) - Edit Torrents Files
* [/r/torrents](https://reddit.com/r/torrents) or [/r/VPNTorrents](https://reddit.com/r/vpntorrents) - Torrenting Discussion
* [IKnowWhatYouDownload](https://iknowwhatyoudownload.com/) - View Torrents Downloaded by your IP (can be inaccurate)
