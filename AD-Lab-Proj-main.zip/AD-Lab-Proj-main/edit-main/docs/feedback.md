---
title: Feedback
description: Anonymous comments taken from Reddit, Discord, X.com and our feedback system.
next: false
prev: false
lastUpdated: false
outline: false
---

### Feedback

:::tip What is this?
These are all anonymous comments taken from Reddit, Discord, X.com and our feedback system. This is why we do it. People are the motivation, equality is the goal.
:::

***

* *"Your sources have allowed me to give my father whatever shows or movies he asks for. Old stuff from when he was younger and all that. Stuff I wouldn't be able to access otherwise. It means a lot since he had heart surgery in Feb 2020 and cant really do much anymore, so its one of the few ways he can keep himself busy. Thank you."*

* *"That's why I love FMHY so much. Before id spend hours and hours every day trying to hunt useful websites for myself."*

* *"I love this website so much. I literally have it labelled as "Everything" in my favorites."*

* *"No bs, and has all the info I need to gain free access to media."*

* *"You have saved me in so many ways that it could not fit here in terms of the amount of text. I'm from a poor "third world" country and a portal like this allows me endless things that I simply can't afford! Keep up the good spirit and I wish you all the best from the bottom of my heart!"*

* *"Y'all have helped not only me but my friends through college and the pandemic in ways you all probably don't even realize."*

* *"Thank you so much for this effort, guys, you are amazing, I stopped searching on google for stuff and got addicted to your website, keep going :)"*

* *"Literally, when I need something, all I need to do is check here first! thank you for being here, for being access to everyone and anyone, I really really appreciate it!"*

* *Shoutout to you guys for letting my 60 year old mother feel like ms hackerman and enjoy her shows.*

* *"Me and my friends call your site the keys to the internet, its kinda amazing."*

* *"Thanks to FMHY, I was able to find a piece of software that upped my efficiency at work three-fold. Literal life-saver. Thank you!"*

* *"Great site! It's so useful, I now know about a lot more apps and such. Definitely made my life easier!"*

* *"I want to express my sincere appreciation for the wiki of useful resources. It has proven to be an invaluable source of information, providing a wide range of knowledge on various topics. The well-organized and comprehensive nature of the wiki has been instrumental in aiding my research and learning. I am truly grateful for the effort and dedication that has gone into curating and maintaining such a valuable repository of knowledge. Thank you for this exceptional resource."*

* *"I'm not kidding when I say my quality of life would be SO. MUCH. LOWER. if it wasn't for the people running this thing, as well as the people running all the tools we get to use. I seriously pray we get at least several more solid years of this style of internet."*

* *"Amazing stuff. Spent almost whole day browsing this and I got introduced to tons of great software. Thank you!!"*

* *I can't begin to express how much of a godsend this website is! Please keep up the terrific work and know that you are making a massive difference in the lives of students like me who can't always pay for subscriptions, or are just looking for a neat tool!*

* *"I love FMHY's wiki, to the point I can't use the internet without it."*

* *"Before finding this, I've been searching google myself and have experienced viruses, fake info, and just bad advice. But the amazing guides and links on FMHY really make it so much safer and simpler to find the things I need. I'm sort of the tech person in my family, so it saves me from so much testing and work."*

* *"This wiki is one of the best out there, seriously. Keep up the great work!"*

* *"This is the best wiki EVER, and I hope that the admins/people maintaining this wiki keep on adding cool stuff like this!"*

* *"I love having an extreme amount of privacy. And it's not just for piracy, so this is REALLY useful. Thanks!"*

* *"Every person I share this sub with is always completely grateful, and it's no wonder why."*

* *"Finding out about FMHY's wiki is the best thing that has happened to me, it has helped me so much in every way imaginable, i'm very grateful, keep it up!"*
