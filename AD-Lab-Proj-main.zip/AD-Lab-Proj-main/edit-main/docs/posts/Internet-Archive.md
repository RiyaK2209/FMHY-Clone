---
title: Internet Archive Breach
description: Internet Archive was hacked
date: 2024-10-09
next: false

prev: false

footer: true
---

<Post authors="nbats" />

#### Internet Archive was hacked today, all 31 million accounts have had their details leaked. If you have an account its *highly* recommended to change your password on the site, as well as anywhere else you are using the same login details.

* https://www.bleepingcomputer.com/news/security/internet-archive-hacked-data-breach-impacts-31-million-users/

* https://haveibeenpwned.com/ 
