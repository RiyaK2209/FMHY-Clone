---
title: Public Discord Server
description: Our new space to chat in.
date: 2023-10-24
next: false

prev: false

footer: true
---

<Post authors="nbats" />

# Public URL: https://rentry.co/fmhy-invite

---

## Server Rules

1. Please be kind and helpful to one another, especially beginners.
2. No selling or advertising anything paid.
3. No direct links to pirated content.
4. No NSFW content (or requests) outside of NSFW channels.
5. No racism, sexism, ableism, homophobia, transphobia.