const fs = require('fs').promises;
const path = require('path');
const { marked } = require('marked');

// Map of category names to their corresponding markdown files
const categoryMap = {
    'Adblocking / Privacy': 'adblockvpnguide.md',
    'Artificial Intelligence': 'ai.md',
    'Streaming': 'videopiracyguide.md',
    'Listening': 'audiopiracyguide.md',
    'Gaming': 'gamingpiracyguide.md',
    'Reading': 'readingpiracyguide.md',
    'Downloading': 'downloadpiracyguide.md',
    'Torrenting': 'torrentpiracyguide.md',
    'Educational': 'edupiracyguide.md',
    'Android / iOS': 'android-iosguide.md',
    'Linux / macOS': 'linuxguide.md',
    'Non English': 'non-english.md',
    'Miscellaneous': 'miscguide.md'
};

async function searchMarkdownFiles(query) {
    const docsDir = path.join(__dirname, '../edit-main/docs');
    const results = [];

    for (const [category, filename] of Object.entries(categoryMap)) {
        try {
            const filePath = path.join(docsDir, filename);
            const content = await fs.readFile(filePath, 'utf-8');
            
            // Convert markdown to plain text for searching
            const plainText = marked.parse(content);
            
            // Simple relevance calculation based on keyword matches
            const queryWords = query.toLowerCase().split(' ');
            let matchCount = 0;
            
            for (const word of queryWords) {
                const regex = new RegExp(word, 'gi');
                const matches = plainText.match(regex) || [];
                matchCount += matches.length;
            }
            
            if (matchCount > 0) {
                // Calculate relevance percentage (simple implementation)
                const relevance = Math.min(100, (matchCount / queryWords.length) * 20);
                
                // Get excerpt (first 200 characters containing the first match)
                const excerpt = plainText.substring(0, 200) + '...';
                
                results.push({
                    title: category,
                    file: filename.replace('.md', ''),
                    excerpt,
                    category,
                    relevance: Math.round(relevance)
                });
            }
        } catch (error) {
            console.error(`Error searching ${filename}:`, error);
        }
    }

    // Sort results by relevance
    return results.sort((a, b) => b.relevance - a.relevance);
}

module.exports = async function(req, res) {
    if (req.method !== 'POST') {
        return res.status(405).json({ error: 'Method not allowed' });
    }

    try {
        const { query } = req.body;
        if (!query) {
            return res.status(400).json({ error: 'Query is required' });
        }

        const results = await searchMarkdownFiles(query);
        res.json(results);
    } catch (error) {
        console.error('Search error:', error);
        res.status(500).json({ error: 'Internal server error' });
    }
}; 