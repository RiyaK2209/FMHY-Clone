// Sample resource data (in a real application, this would come from a backend)
const resources = [
    {
        title: 'Streaming Guide',
        description: 'A comprehensive guide to streaming platforms and services.',
        category: 'Streaming',
        icon: 'fa-video'
    },
    {
        title: 'Reading Resources',
        description: 'Collection of e-books and reading materials.',
        category: 'Reading',
        icon: 'fa-book'
    },
    {
        title: 'Gaming Hub',
        description: 'Everything you need to know about gaming.',
        category: 'Gaming',
        icon: 'fa-gamepad'
    },
    {
        title: 'Music Collection',
        description: 'Curated list of music resources and tools.',
        category: 'Music',
        icon: 'fa-music'
    }
];

// Function to create resource cards
function createResourceCard(resource) {
    return `
        <div class="resource-card">
            <i class="fas ${resource.icon}"></i>
            <h3>${resource.title}</h3>
            <p>${resource.description}</p>
            <span class="category">${resource.category}</span>
        </div>
    `;
}

// Populate resource grid
function populateResources() {
    const resourceGrid = document.querySelector('.resource-grid');
    if (resourceGrid) {
        resourceGrid.innerHTML = resources.map(createResourceCard).join('');
    }
}

// Search functionality
function setupSearch() {
    const searchInputs = document.querySelectorAll('input[type="text"]');
    searchInputs.forEach(input => {
        input.addEventListener('input', (e) => {
            const query = e.target.value.toLowerCase();
            const filteredResources = resources.filter(resource => 
                resource.title.toLowerCase().includes(query) ||
                resource.description.toLowerCase().includes(query) ||
                resource.category.toLowerCase().includes(query)
            );
            
            const resourceGrid = document.querySelector('.resource-grid');
            if (resourceGrid) {
                resourceGrid.innerHTML = filteredResources.map(createResourceCard).join('');
            }
        });
    });
}

// Add smooth scrolling for navigation links
function setupSmoothScroll() {
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function (e) {
            e.preventDefault();
            const target = document.querySelector(this.getAttribute('href'));
            if (target) {
                target.scrollIntoView({
                    behavior: 'smooth'
                });
            }
        });
    });
}

//adding sidebar
// Sidebar Toggle Functionality
function setupSidebar() {
    const sidebar = document.querySelector('.sidebar');
    const mainContent = document.querySelector('.main-content');
    const sidebarToggle = document.querySelector('.sidebar-toggle');

    if (sidebar && sidebarToggle && mainContent) {
        sidebarToggle.addEventListener('click', () => {
            sidebar.classList.toggle('collapsed');
            mainContent.classList.toggle('shifted');
        });
    }
}

// Initialize all functions when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    populateResources();
    setupSearch();
    setupSmoothScroll();
    setupLoginPopup();
    setupSidebar(); // New sidebar functionality
});


// Login Popup Functionality
function setupLoginPopup() {
    const loginBtn = document.querySelector('.login-btn');
    const loginPopup = document.getElementById('login-popup');
    const closeBtn = document.querySelector('.close-btn');

    if (loginBtn && loginPopup && closeBtn) {
        loginBtn.addEventListener('click', function(event) {
            event.preventDefault();
            loginPopup.style.display = 'flex';
            document.body.classList.add('blur-background'); // Blur effect
        });

        closeBtn.addEventListener('click', function() {
            loginPopup.style.display = 'none';
            document.body.classList.remove('blur-background');
        });

        window.addEventListener('click', function(event) {
            if (event.target === loginPopup) {
                loginPopup.style.display = 'none';
                document.body.classList.remove('blur-background');
            }
        });
    }
}




// Initialize when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    populateResources();
    setupSearch();
    setupSmoothScroll();
    setupLoginPopup();
}); 



