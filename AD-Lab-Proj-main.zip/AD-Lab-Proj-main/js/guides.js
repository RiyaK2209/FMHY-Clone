// Configure marked for security
marked.setOptions({
    headerIds: false,
    mangle: false
});

// Function to load and render markdown content
async function loadGuide(guideName) {
    const contentDiv = document.getElementById('guide-content');
    contentDiv.innerHTML = '<div class="loading">Loading guide...</div>';

    try {
        const response = await fetch(`../edit-main/docs/${guideName}.md`);
        if (!response.ok) throw new Error('Guide not found');
        
        const markdown = await response.text();
        const htmlContent = marked.parse(markdown);
        const sanitizedContent = DOMPurify.sanitize(htmlContent);
        
        contentDiv.innerHTML = sanitizedContent;

        // Update active state in sidebar
        document.querySelectorAll('.guide-list a').forEach(link => {
            link.classList.remove('active');
            if (link.dataset.guide === guideName) {
                link.classList.add('active');
            }
        });

        // Update URL without page reload
        const url = new URL(window.location);
        url.searchParams.set('guide', guideName);
        window.history.pushState({}, '', url);

    } catch (error) {
        contentDiv.innerHTML = `
            <div class="error">
                <h2>Error Loading Guide</h2>
                <p>Sorry, we couldn't load the requested guide. Please try again later.</p>
            </div>
        `;
    }
}

// Handle guide links
document.addEventListener('DOMContentLoaded', () => {
    // Add click handlers to guide links
    document.querySelectorAll('.guide-list a').forEach(link => {
        link.addEventListener('click', (e) => {
            e.preventDefault();
            const guideName = e.target.dataset.guide;
            loadGuide(guideName);
        });
    });

    // Load guide from URL parameter or default to beginners guide
    const urlParams = new URLSearchParams(window.location.search);
    const guideParam = urlParams.get('guide');
    loadGuide(guideParam || 'beginners-guide');

    // Setup search functionality
    const searchInput = document.querySelector('.nav-search input');
    searchInput.addEventListener('input', (e) => {
        const query = e.target.value.toLowerCase();
        document.querySelectorAll('.guide-list a').forEach(link => {
            const text = link.textContent.toLowerCase();
            link.parentElement.style.display = text.includes(query) ? '' : 'none';
        });
    });
});

// Handle browser back/forward buttons
window.addEventListener('popstate', () => {
    const urlParams = new URLSearchParams(window.location.search);
    const guideParam = urlParams.get('guide');
    loadGuide(guideParam || 'beginners-guide');
}); 