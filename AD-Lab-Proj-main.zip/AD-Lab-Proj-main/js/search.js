// Search state
let currentQuery = '';
let currentFilter = 'all';
let currentPage = 1;
const resultsPerPage = 10;
let searchResults = [];
let searchTimeout;

// Initialize search functionality
document.addEventListener('DOMContentLoaded', () => {
    const isSearchPage = window.location.pathname.includes('/search.html');
    
    if (isSearchPage) {
        initializeSearchPage();
    } else {
        initializeHomeSearch();
    }
});

// Initialize search page functionality
function initializeSearchPage() {
    // Get DOM elements
    const searchInput = document.getElementById('search-input');
    const searchButton = document.getElementById('search-button');
    const resultsContainer = document.getElementById('results-container');
    const resultsCount = document.getElementById('results-count');
    const loadingIndicator = document.getElementById('search-loading');
    const filterButtons = document.querySelectorAll('.filter-btn');
    const prevPageBtn = document.getElementById('prev-page');
    const nextPageBtn = document.getElementById('next-page');
    const pageInfo = document.getElementById('page-info');

    // Get search query from URL
    const urlParams = new URLSearchParams(window.location.search);
    const queryParam = urlParams.get('q');
    if (queryParam) {
        searchInput.value = queryParam;
        performSearch(queryParam);
    }

    // Search input handler with debounce
    searchInput.addEventListener('input', (e) => {
        clearTimeout(searchTimeout);
        searchTimeout = setTimeout(() => {
            const query = e.target.value.trim();
            if (query.length >= 2) {
                performSearch(query);
                updateURL(query);
            }
        }, 300);
    });

    // Search button click handler
    searchButton.addEventListener('click', () => {
        const query = searchInput.value.trim();
        if (query.length >= 2) {
            performSearch(query);
            updateURL(query);
        }
    });

    // Filter button handlers
    filterButtons.forEach(btn => {
        btn.addEventListener('click', () => {
            filterButtons.forEach(b => b.classList.remove('active'));
            btn.classList.add('active');
            currentFilter = btn.dataset.filter;
            filterResults();
        });
    });

    // Pagination handlers
    prevPageBtn.addEventListener('click', () => {
        if (currentPage > 1) {
            currentPage--;
            displayResults();
        }
    });

    nextPageBtn.addEventListener('click', () => {
        const maxPages = Math.ceil(searchResults.length / resultsPerPage);
        if (currentPage < maxPages) {
            currentPage++;
            displayResults();
        }
    });

    // Perform search
    async function performSearch(query) {
        if (query === currentQuery) return;
        currentQuery = query;
        showLoading(true);

        try {
            // Use the full URL including port
            const response = await fetch('http://localhost:5500/api/search', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({ query })
            });

            if (!response.ok) {
                throw new Error('Search request failed');
            }

            const data = await response.json();
            searchResults = data;
            currentPage = 1;
            filterResults();
            showLoading(false);
        } catch (error) {
            console.error('Search failed:', error);
            showLoading(false);
            displayError('Search failed. Please try again.');
        }
    }

    // Filter results based on current filter
    function filterResults() {
        let filtered = [...searchResults];
        
        if (currentFilter !== 'all') {
            filtered = searchResults.filter(result => {
                switch (currentFilter) {
                    case 'guides':
                        return result.category === 'Guide';
                    case 'tools':
                        return result.category === 'Tools';
                    case 'resources':
                        return result.category === 'Resource';
                    default:
                        return true;
                }
            });
        }

        resultsCount.textContent = `Found ${filtered.length} results`;
        displayResultsList(filtered);
    }

    // Display results with pagination
    function displayResultsList(results) {
        const start = (currentPage - 1) * resultsPerPage;
        const end = start + resultsPerPage;
        const pageResults = results.slice(start, end);
        
        resultsContainer.innerHTML = '';

        if (pageResults.length === 0) {
            resultsContainer.innerHTML = '<div class="no-results">No results found</div>';
            return;
        }

        pageResults.forEach(result => {
            const resultElement = createResultElement(result);
            resultsContainer.appendChild(resultElement);
        });

        updatePagination(results.length);
    }

    // Create result element
    function createResultElement(result) {
        const div = document.createElement('div');
        div.className = 'search-result-item';
        div.innerHTML = `
            <h3><a href="/pages/guides.html?guide=${result.file}">${result.title}</a></h3>
            <p>${result.excerpt}</p>
            <div class="result-meta">
                <span class="category">${result.category}</span>
                <span class="relevance">Relevance: ${result.relevance}%</span>
            </div>
        `;
        return div;
    }

    // Update pagination controls
    function updatePagination(totalResults) {
        const maxPages = Math.ceil(totalResults / resultsPerPage);
        pageInfo.textContent = `Page ${currentPage} of ${maxPages}`;
        prevPageBtn.disabled = currentPage === 1;
        nextPageBtn.disabled = currentPage === maxPages;
    }

    // Show/hide loading indicator
    function showLoading(show) {
        loadingIndicator.style.display = show ? 'flex' : 'none';
        resultsContainer.style.opacity = show ? '0.5' : '1';
    }

    // Display error message
    function displayError(message) {
        resultsContainer.innerHTML = `<div class="error">${message}</div>`;
        resultsCount.textContent = '';
    }
}

// Initialize home page search
function initializeHomeSearch() {
    const searchForm = document.querySelector('.search-large');
    if (searchForm) {
        searchForm.addEventListener('submit', (e) => {
            const input = searchForm.querySelector('input');
            const query = input.value.trim();
            if (query.length < 2) {
                e.preventDefault();
            }
        });
    }
}

// Update URL with search query
function updateURL(query) {
    const url = new URL(window.location);
    url.searchParams.set('q', query);
    window.history.pushState({}, '', url);
}

// Search functionality implementation
class SearchEngine {
    constructor() {
        this.searchInput = document.querySelector('.search-large input');
        this.searchButton = document.querySelector('.search-large button');
        this.searchResults = document.createElement('div');
        this.searchResults.className = 'search-results';
        this.searchInput.parentNode.appendChild(this.searchResults);
        
        this.setupEventListeners();
    }

    setupEventListeners() {
        this.searchButton.addEventListener('click', () => this.performSearch());
        this.searchInput.addEventListener('keypress', (e) => {
            if (e.key === 'Enter') {
                this.performSearch();
            }
        });
    }

    async performSearch() {
        const query = this.searchInput.value.trim().toLowerCase();
        if (!query) return;

        this.searchResults.innerHTML = '<div class="loading">Searching...</div>';
        
        try {
            const response = await fetch('/api/search', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({ query })
            });

            const results = await response.json();
            this.displayResults(results);
        } catch (error) {
            this.searchResults.innerHTML = '<div class="error">Error performing search. Please try again.</div>';
            console.error('Search error:', error);
        }
    }

    displayResults(results) {
        if (!results.length) {
            this.searchResults.innerHTML = '<div class="no-results">No results found</div>';
            return;
        }

        const resultsHTML = results.map(result => `
            <div class="search-result-item">
                <h3><a href="/pages/guides.html?guide=${result.file}">${result.title}</a></h3>
                <p>${result.excerpt}</p>
                <div class="result-meta">
                    <span class="category">${result.category}</span>
                    <span class="relevance">Relevance: ${result.relevance}%</span>
                </div>
            </div>
        `).join('');

        this.searchResults.innerHTML = resultsHTML;
    }
}

// Initialize search when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    new SearchEngine();
}); 